package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Reusable Emoji and Sticker Picker component for chat message input bar.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmojiStickerPicker(
    onEmojiSelected: (String) -> Unit,
    onStickerSelected: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var mainTab by remember { mutableStateOf(0) } // 0 = Emojis, 1 = Stickers
    var searchQuery by remember { mutableStateOf("") }
    var selectedEmojiCategory by remember { mutableStateOf("Smileys") }
    var selectedStickerCategory by remember { mutableStateOf("Cute Cats") }

    // Emojis grouped by categories
    val emojiCategories = mapOf(
        "Smileys" to listOf(
            "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇",
            "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚",
            "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🤩",
            "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "😣", "😖"
        ),
        "Gestures" to listOf(
            "👍", "👎", "👊", "✊", "🤛", "🤜", "🤞", "✌️", "🤟", "🤘",
            "👌", "🤌", "🤏", "👈", "👉", "👆", "👇", "☝️", "✋", "🤚",
            "🖐️", "🖖", "👋", "🤙", "💪", "🖕", "✍️", "🙏", "👏", "🙌"
        ),
        "Hearts" to listOf(
            "❤️", "🩷", "🧡", "💛", "💚", "💙", "🩵", "💜", "🖤", "🩶",
            "🤍", "🤎", "💔", "❤️‍🔥", "❤️‍🩹", "❣️", "💕", "💞", "💓", "💗",
            "💖", "💘", "💝", "💟", "💌", "💋", "👨‍❤️‍💋‍👨", "👩‍❤️‍💋‍👩"
        ),
        "Food" to listOf(
            "🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐",
            "🍈", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅", "🥑", "🥦",
            "🍔", "🍟", "🍕", "🌭", "🥪", "🌮", "🌯", "🫔", "🥙", "🧆",
            "🍿", "🎂", "🍰", "🧁", "🥧", "🍫", "🍬", "🍭", "🍩", "🍪"
        ),
        "Objects" to listOf(
            "🔥", "✨", "🌟", "🎉", "🎊", "💯", "🚀", "🎁", "🎈", "🌺",
            "💡", "🔔", "📱", "💻", "⌨️", "🎧", "📷", "📸", "📹", "⏰",
            "🔮", "🎯", "🎲", "🧩", "🎨", "🎭", "🎤", "🎧", "🎼", "🎹"
        )
    )

    // Stickers grouped by categories
    val stickerCategories = mapOf(
        "Cute Cats" to listOf(
            "🐱 Hello!", "🐱 Love You!", "🐱 Sleepy...", "🐱 Angry Cat!",
            "🐱 Play Time!", "🐱 Hungry!", "🐱 Paw Five!", "🐱 Purr-fect!"
        ),
        "Gentle Bears" to listOf(
            "🐻 Big Hug!", "🐻 Thank You!", "🐻 Good Night!", "🐻 Super Hero!",
            "🐻 Beary Happy!", "🐻 Honey Time", "🐻 Need Coffee", "🐻 Miss You!"
        ),
        "Cool Vibes" to listOf(
            "😎 Cool Vibe!", "🎉 Party Time!", "🔥 On Fire!", "💯 100% Ready!",
            "✨ Sparkles!", "🚀 To The Moon!", "☕ Coffee First!", "❤️ Heart Beat!"
        ),
        "Daily Memes" to listOf(
            "😂 NO WAY!", "🤯 MIND BLOWN!", "👀 SUS...", "👏 BRAVO!",
            "😴 NO SLEEP", "🤫 TOP SECRET", "💪 BEAST MODE", "🤝 DEAL DONE!"
        )
    )

    // Filtered emojis based on search
    val currentEmojis = if (searchQuery.isNotBlank()) {
        emojiCategories.values.flatten().filter { it.contains(searchQuery, ignoreCase = true) }
    } else {
        emojiCategories[selectedEmojiCategory] ?: emptyList()
    }

    // Filtered stickers based on search
    val currentStickers = if (searchQuery.isNotBlank()) {
        stickerCategories.values.flatten().filter { it.contains(searchQuery, ignoreCase = true) }
    } else {
        stickerCategories[selectedStickerCategory] ?: emptyList()
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .testTag("emoji_sticker_picker"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Top Header Bar: Main Tabs & Close Action
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = (mainTab == 0),
                        onClick = { mainTab = 0 },
                        label = { Text("😀 Emojis", fontWeight = FontWeight.SemiBold) },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.testTag("emoji_tab")
                    )
                    FilterChip(
                        selected = (mainTab == 1),
                        onClick = { mainTab = 1 },
                        label = { Text("🎨 Stickers", fontWeight = FontWeight.SemiBold) },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.testTag("sticker_tab")
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.testTag("close_picker_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Picker",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Search Bar & Sub-Category Row
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Compact Search Input Field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = if (mainTab == 0) "Search emojis..." else "Search stickers...",
                            fontSize = 12.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search",
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("picker_search_input"),
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    ),
                    singleLine = true
                )

                // Sub-category Chips (only when search query is empty)
                if (searchQuery.isEmpty()) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (mainTab == 0) {
                            items(emojiCategories.keys.toList()) { cat ->
                                SuggestionChip(
                                    onClick = { selectedEmojiCategory = cat },
                                    label = {
                                        Text(
                                            text = cat,
                                            fontSize = 12.sp,
                                            fontWeight = if (selectedEmojiCategory == cat) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = if (selectedEmojiCategory == cat)
                                            MaterialTheme.colorScheme.primaryContainer
                                        else
                                            MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        } else {
                            items(stickerCategories.keys.toList()) { cat ->
                                SuggestionChip(
                                    onClick = { selectedStickerCategory = cat },
                                    label = {
                                        Text(
                                            text = cat,
                                            fontSize = 12.sp,
                                            fontWeight = if (selectedStickerCategory == cat) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = if (selectedStickerCategory == cat)
                                            MaterialTheme.colorScheme.primaryContainer
                                        else
                                            MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Grid Content Display
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                if (mainTab == 0) {
                    // Emojis Grid
                    if (currentEmojis.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No emojis found", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 42.dp),
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(currentEmojis) { emoji ->
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .clickable { onEmojiSelected(emoji) }
                                        .testTag("emoji_item_$emoji"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = emoji, fontSize = 24.sp)
                                }
                            }
                        }
                    }
                } else {
                    // Stickers Grid
                    if (currentStickers.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No stickers found", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(currentStickers) { sticker ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable { onStickerSelected(sticker) }
                                        .testTag("sticker_item_$sticker"),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = sticker,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
