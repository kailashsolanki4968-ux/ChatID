package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class WallpaperOption(
    val key: String,
    val name: String,
    val category: String, // "Patterns", "Gradients", "Solid"
    val primaryColor: Color,
    val secondaryColor: Color? = null,
    val isDarkText: Boolean = false
)

val WALLPAPER_OPTIONS = listOf(
    WallpaperOption("DEFAULT", "Default Theme", "Classic", Color(0xFFF8F9FA), Color(0xFFE9ECEF), true),
    WallpaperOption("DOODLE", "Chat Doodles", "Patterns", Color(0xFFEFEAE2), Color(0xFFE3DAC9), true),
    WallpaperOption("GEOMETRIC", "Tech Grid", "Patterns", Color(0xFF1E293B), Color(0xFF0F172A), false),
    WallpaperOption("OCEAN", "Ocean Breeze", "Gradients", Color(0xFF0284C7), Color(0xFF06B6D4), false),
    WallpaperOption("SUNSET", "Sunset Glow", "Gradients", Color(0xFFF43F5E), Color(0xFFA855F7), false),
    WallpaperOption("MIDNIGHT", "Midnight Neon", "Gradients", Color(0xFF0F172A), Color(0xFF581C87), false),
    WallpaperOption("EMERALD", "Emerald Forest", "Gradients", Color(0xFF047857), Color(0xFF10B981), false),
    WallpaperOption("PASTEL_PINK", "Pastel Pink", "Gradients", Color(0xFFFCE7F3), Color(0xFFFBCFE8), true),
    WallpaperOption("CHARCOAL", "Matte Charcoal", "Gradients", Color(0xFF18181B), Color(0xFF27272A), false),
    WallpaperOption("SOLID_MINT", "Solid Mint", "Solid", Color(0xFFE6F4EA), null, true),
    WallpaperOption("SOLID_LAVENDER", "Solid Lavender", "Solid", Color(0xFFF3E8FF), null, true),
    WallpaperOption("SOLID_CREAM", "Warm Cream", "Solid", Color(0xFFFFFBEB), null, true),
    WallpaperOption("SOLID_NAVY", "Royal Navy", "Solid", Color(0xFF1E3A8A), null, false)
)

@Composable
fun ChatWallpaperBackground(
    wallpaperKey: String,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val option = WALLPAPER_OPTIONS.find { it.key == wallpaperKey } ?: WALLPAPER_OPTIONS.first()

    val backgroundModifier = when {
        option.secondaryColor != null -> {
            modifier.background(
                brush = Brush.verticalGradient(
                    colors = listOf(option.primaryColor, option.secondaryColor)
                )
            )
        }
        else -> {
            modifier.background(option.primaryColor)
        }
    }

    Box(modifier = backgroundModifier) {
        // Pattern Overlays
        when (wallpaperKey) {
            "DOODLE" -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    val dotColor = Color(0xFF78350F).copy(alpha = 0.08f)

                    // Draw subtle doodle circles and grid dots
                    for (x in 20..width.toInt() step 60) {
                        for (y in 20..height.toInt() step 60) {
                            val radius = if ((x + y) % 120 == 0) 6f else 3f
                            drawCircle(
                                color = dotColor,
                                radius = radius,
                                center = Offset(x.toFloat(), y.toFloat())
                            )
                        }
                    }
                }
            }
            "GEOMETRIC" -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    val lineColor = Color(0xFF38BDF8).copy(alpha = 0.07f)

                    for (x in 0..width.toInt() step 40) {
                        drawLine(
                            color = lineColor,
                            start = Offset(x.toFloat(), 0f),
                            end = Offset(x.toFloat(), height),
                            strokeWidth = 1f
                        )
                    }
                    for (y in 0..height.toInt() step 40) {
                        drawLine(
                            color = lineColor,
                            start = Offset(0f, y.toFloat()),
                            end = Offset(width, y.toFloat()),
                            strokeWidth = 1f
                        )
                    }
                }
            }
        }

        content()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WallpaperPickerDialog(
    currentWallpaperKey: String,
    onWallpaperSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var previewKey by remember { mutableStateOf(currentWallpaperKey) }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Classic", "Patterns", "Gradients", "Solid")
    val filteredOptions = remember(selectedCategory) {
        if (selectedCategory == "All") WALLPAPER_OPTIONS
        else WALLPAPER_OPTIONS.filter { it.category == selectedCategory }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("wallpaper_picker_dialog"),
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Chat Wallpaper & Theme",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Live Preview Canvas Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                ) {
                    ChatWallpaperBackground(
                        wallpaperKey = previewKey,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Incoming Preview Bubble
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp, bottomEnd = 12.dp, bottomStart = 2.dp))
                                    .background(Color.White.copy(alpha = 0.9f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "Hey! How does this wallpaper look? ✨",
                                    fontSize = 12.sp,
                                    color = Color.Black
                                )
                            }

                            // Outgoing Preview Bubble
                            Box(
                                modifier = Modifier
                                    .align(Alignment.End)
                                    .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp, bottomEnd = 2.dp, bottomStart = 12.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "Looks super sleek! 🔥",
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Category Chips
                ScrollableTabRow(
                    selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            modifier = Modifier.padding(end = 6.dp),
                            shape = RoundedCornerShape(16.dp)
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Grid of Options
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredOptions) { option ->
                        val isSelected = previewKey == option.key
                        Card(
                            modifier = Modifier
                                .height(80.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { previewKey = option.key }
                                .testTag("wallpaper_item_${option.key}"),
                            shape = RoundedCornerShape(12.dp),
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                ChatWallpaperBackground(
                                    wallpaperKey = option.key,
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(4.dp),
                                        contentAlignment = Alignment.BottomStart
                                    ) {
                                        Text(
                                            text = option.name,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (option.isDarkText) Color.Black.copy(alpha = 0.8f) else Color.White,
                                            maxLines = 1,
                                            modifier = Modifier
                                                .background(
                                                    if (option.isDarkText) Color.White.copy(alpha = 0.7f) else Color.Black.copy(alpha = 0.5f),
                                                    RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }

                                    if (isSelected) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(4.dp)
                                                .size(20.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primary),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            previewKey = "DEFAULT"
                        },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Reset", fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            onWallpaperSelected(previewKey)
                            onDismiss()
                        },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("apply_wallpaper_button")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Apply Wallpaper", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
