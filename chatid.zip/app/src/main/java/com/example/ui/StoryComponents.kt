package com.example.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.NoteEntity
import com.example.data.StoryDraftEntity
import com.example.data.StoryEntity
import com.example.data.UserEntity
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

// --- Data Models for Music & Media Presets ---
data class MusicTrack(
    val title: String,
    val artist: String,
    val duration: String,
    val coverEmoji: String,
    val gradientName: String
)

object CuratedMusic {
    val tracks = listOf(
        MusicTrack("Kesariya", "Arijit Singh", "2:52", "🧡", "SUNSET"),
        MusicTrack("Blinding Lights", "The Weeknd", "3:20", "⚡", "NEON_NIGHT"),
        MusicTrack("Levitating", "Dua Lipa", "3:23", "✨", "PURPLE_DREAM"),
        MusicTrack("Apna Bana Le", "Arijit Singh", "3:42", "💖", "PEACH"),
        MusicTrack("Starboy", "The Weeknd", "3:50", "🌟", "MINIMAL_DARK"),
        MusicTrack("Night Changes", "One Direction", "3:46", "🌙", "OCEAN"),
        MusicTrack("Shape of You", "Ed Sheeran", "3:53", "🎸", "EMERALD"),
        MusicTrack("Lover", "Taylor Swift", "3:41", "🌸", "PEACH"),
        MusicTrack("Stay", "The Kid LAROI & Justin Bieber", "2:21", "🔥", "CRIMSON"),
        MusicTrack("Pasoori", "Ali Sethi & Shae Gill", "3:44", "☕", "SUNSET"),
        MusicTrack("Calm Down", "Rema & Selena Gomez", "3:59", "🌴", "EMERALD"),
        MusicTrack("Heeriye", "Jasleen Royal & Arijit Singh", "3:14", "💫", "PURPLE_DREAM")
    )
}

data class MediaPreset(
    val id: String,
    val title: String,
    val subtitle: String,
    val iconEmoji: String,
    val type: String, // "PHOTO", "VIDEO"
    val gradientKey: String
)

object MediaCatalog {
    val presets = listOf(
        MediaPreset("CAFE_VIBES", "Cozy Coffeehouse", "Warm aroma & lo-fi cafe vibes", "☕", "PHOTO", "SUNSET"),
        MediaPreset("NEON_CYBER", "Cyberpunk Neon City", "Electric night motion & neon glows", "⚡", "VIDEO", "NEON_NIGHT"),
        MediaPreset("SUNSET_BEACH", "Golden Sunset Glow", "Ocean twilight horizon & waves", "🌅", "PHOTO", "PEACH"),
        MediaPreset("MOUNTAIN_VIEW", "Misty Alpine Peak", "Serene mountain morning clouds", "🏔️", "PHOTO", "EMERALD"),
        MediaPreset("RAINY_WINDOW", "Rainy Window Drops", "Moody rainfall bokeh & chill", "🌧️", "VIDEO", "OCEAN"),
        MediaPreset("STUDY_DESK", "Lofi Workspace Setup", "Warm keyboard lighting & focus", "💻", "PHOTO", "PURPLE_DREAM"),
        MediaPreset("PARTY_NIGHT", "Electric Disco Lights", "Strobe flares & energetic dance", "🎉", "VIDEO", "CRIMSON"),
        MediaPreset("MINIMAL_ART", "Pastel Abstract Canvas", "Clean geometric artistic mood", "🎨", "PHOTO", "MINIMAL_DARK")
    )
}

object StoryGradients {
    val gradients = mapOf(
        "SUNSET" to listOf(Color(0xFFFF512F), Color(0xFFDD2476)),
        "OCEAN" to listOf(Color(0xFF2193B0), Color(0xFF6DD5ED)),
        "EMERALD" to listOf(Color(0xFF11998E), Color(0xFF38EF7D)),
        "PURPLE_DREAM" to listOf(Color(0xFF8E2DE2), Color(0xFF4A00E0)),
        "NEON_NIGHT" to listOf(Color(0xFF00F260), Color(0xFF0575E6)),
        "CRIMSON" to listOf(Color(0xFFE52D27), Color(0xFFB31217)),
        "PEACH" to listOf(Color(0xFFF857A6), Color(0xFFFF5858)),
        "MINIMAL_DARK" to listOf(Color(0xFF1E2022), Color(0xFF3B3E42))
    )

    fun getBrush(name: String): Brush {
        val colors = gradients[name] ?: gradients["SUNSET"]!!
        return Brush.linearGradient(colors)
    }
}

// ==========================================
// 1. INSTAGRAM-STYLE 24-HOUR NOTES ROW
// ==========================================

@Composable
fun InstagramNotesRow(
    currentUser: UserEntity,
    notes: List<NoteEntity>,
    allUsers: List<UserEntity>,
    onAddNoteClick: () -> Unit,
    onNoteClick: (note: NoteEntity, user: UserEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val usersMap = remember(allUsers) { allUsers.associateBy { it.userId } }
    val now = System.currentTimeMillis()
    val activeNotes = remember(notes) { notes.filter { it.expiresAt > now } }
    val myNote = remember(activeNotes, currentUser.userId) { activeNotes.find { it.userId == currentUser.userId } }
    val otherNotes = remember(activeNotes, currentUser.userId) { activeNotes.filter { it.userId != currentUser.userId } }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Notes (24h)",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.tertiaryContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = "Music",
                            tint = MaterialTheme.colorScheme.onTertiaryContainer,
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = "Music Notes",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            }

            Text(
                text = "Share a thought",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onAddNoteClick() }
            )
        }

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. My Note / Add Note
            item(key = "my_note") {
                NoteBubbleItem(
                    isMyNote = true,
                    displayName = "Your Note",
                    userId = currentUser.userId,
                    avatarColorHex = currentUser.avatarColorHex,
                    noteText = myNote?.text,
                    musicTitle = myNote?.musicTitle,
                    musicArtist = myNote?.musicArtist,
                    onClick = {
                        if (myNote != null) {
                            onNoteClick(myNote, currentUser)
                        } else {
                            onAddNoteClick()
                        }
                    }
                )
            }

            // 2. Friends' Notes
            items(otherNotes, key = { it.userId }) { note ->
                val user = usersMap[note.userId] ?: UserEntity(note.userId, note.userId.removePrefix("@"))
                NoteBubbleItem(
                    isMyNote = false,
                    displayName = user.displayName,
                    userId = user.userId,
                    avatarColorHex = user.avatarColorHex,
                    noteText = note.text,
                    musicTitle = note.musicTitle,
                    musicArtist = note.musicArtist,
                    onClick = {
                        onNoteClick(note, user)
                    }
                )
            }
        }
    }
}

@Composable
fun NoteBubbleItem(
    isMyNote: Boolean,
    displayName: String,
    userId: String,
    avatarColorHex: String,
    noteText: String?,
    musicTitle: String?,
    musicArtist: String?,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(82.dp)
            .clickable { onClick() }
            .testTag(if (isMyNote) "note_item_my" else "note_item_$userId")
    ) {
        // Thought bubble floating on top of avatar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            if (noteText != null || musicTitle != null) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    tonalElevation = 4.dp,
                    shadowElevation = 2.dp,
                    modifier = Modifier.padding(bottom = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (!noteText.isNullOrBlank()) {
                            Text(
                                text = noteText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (!musicTitle.isNullOrBlank()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = "Music",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(9.dp)
                                )
                                Text(
                                    text = musicTitle,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            } else if (isMyNote) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
                    modifier = Modifier.padding(bottom = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Share",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(10.dp)
                        )
                        Text(
                            text = "Note...",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Avatar
        Box(
            modifier = Modifier.size(54.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(parseHexColor(avatarColorHex)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = displayName.take(1).uppercase(),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (isMyNote && noteText == null && musicTitle == null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.background)
                        .padding(1.5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add",
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = if (isMyNote) "Your Note" else displayName,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

// ==========================================
// 2. CREATE NOTE DIALOG (WITH MUSIC TRACK)
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateNoteDialog(
    currentUser: UserEntity,
    currentNote: NoteEntity?,
    onDismiss: () -> Unit,
    onPostNote: (text: String, musicTitle: String?, musicArtist: String?) -> Unit,
    onDeleteNote: () -> Unit
) {
    var noteText by remember { mutableStateOf(currentNote?.text ?: "") }
    var selectedMusic by remember {
        mutableStateOf<MusicTrack?>(
            if (currentNote?.musicTitle != null) {
                CuratedMusic.tracks.find { it.title == currentNote.musicTitle } ?: MusicTrack(currentNote.musicTitle, currentNote.musicArtist ?: "", "3:00", "🎵", "SUNSET")
            } else null
        )
    }
    var showMusicPicker by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Share a Note (24h)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("Disappears in 24 hours", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    },
                    actions = {
                        if (currentNote != null) {
                            IconButton(onClick = {
                                onDeleteNote()
                                onDismiss()
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Note", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                        Button(
                            onClick = {
                                if (noteText.isNotBlank() || selectedMusic != null) {
                                    onPostNote(noteText.trim(), selectedMusic?.title, selectedMusic?.artist)
                                    onDismiss()
                                }
                            },
                            enabled = noteText.isNotBlank() || selectedMusic != null,
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text("Share", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Live Note Avatar & Thought Bubble Preview
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 20.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shadowElevation = 6.dp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (noteText.isNotBlank()) noteText else "Share what's on your mind...",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            if (selectedMusic != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.MusicNote,
                                        contentDescription = "Music",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "${selectedMusic!!.title} • ${selectedMusic!!.artist}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(parseHexColor(currentUser.avatarColorHex)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentUser.displayName.take(1).uppercase(),
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Input Field
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { if (it.length <= 60) noteText = it },
                    placeholder = { Text("Share a thought (Max 60 chars)...") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    maxLines = 2,
                    supportingText = { Text("${noteText.length}/60 characters") }
                )

                // Add Music Action Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { showMusicPicker = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = "Add Music", tint = MaterialTheme.colorScheme.primary)
                            }
                            Column {
                                Text(
                                    text = if (selectedMusic != null) selectedMusic!!.title else "Add Music / Song to Note",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (selectedMusic != null) selectedMusic!!.artist else "Pick songs like Kesariya, Starboy, Levitating...",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (selectedMusic != null) {
                            IconButton(onClick = { selectedMusic = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove Song")
                            }
                        } else {
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            if (showMusicPicker) {
                MusicPickerSheet(
                    onDismiss = { showMusicPicker = false },
                    onTrackSelected = { track ->
                        selectedMusic = track
                        showMusicPicker = false
                    }
                )
            }
        }
    }
}

// ==========================================
// 3. MUSIC PICKER BOTTOM SHEET
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicPickerSheet(
    onDismiss: () -> Unit,
    onTrackSelected: (MusicTrack) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredTracks = remember(searchQuery) {
        if (searchQuery.isBlank()) CuratedMusic.tracks
        else CuratedMusic.tracks.filter {
            it.title.contains(searchQuery, ignoreCase = true) || it.artist.contains(searchQuery, ignoreCase = true)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.LibraryMusic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Select Song / Music", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search songs or artists...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filteredTracks) { track ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onTrackSelected(track) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(StoryGradients.getBrush(track.gradientName)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(track.coverEmoji, fontSize = 20.sp)
                                }

                                Column {
                                    Text(track.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(track.artist, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(track.duration, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Icon(Icons.Default.PlayCircle, contentDescription = "Pick Song", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// ==========================================
// 4. NOTE DETAIL & REPLY DIALOG
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteDetailDialog(
    note: NoteEntity,
    user: UserEntity,
    currentUser: UserEntity,
    onDismiss: () -> Unit,
    onReplyToNote: (message: String) -> Unit,
    onDeleteNote: (() -> Unit)? = null
) {
    var replyText by remember { mutableStateOf("") }
    val isMyNote = note.userId == currentUser.userId

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // User & Thought bubble
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(parseHexColor(user.avatarColorHex)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(user.displayName.take(1).uppercase(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }

                Text(user.displayName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(user.userId, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)

                // Note Content Card
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (note.text.isNotBlank()) {
                            Text(
                                text = "\"${note.text}\"",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                textAlign = TextAlign.Center
                            )
                        }
                        if (note.musicTitle != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                                Text(
                                    text = "${note.musicTitle} • ${note.musicArtist ?: ""}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                Text(
                    text = "⏳ Disappears in ${calculateHoursRemaining(note.expiresAt)}h",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (!isMyNote) {
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        placeholder = { Text("Reply to note...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    if (replyText.isNotBlank()) {
                                        onReplyToNote("Replied to note \"${note.text}\": $replyText")
                                        onDismiss()
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    )
                } else {
                    Button(
                        onClick = {
                            onDeleteNote?.invoke()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.onErrorContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Delete Note")
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. 24-HOUR STORIES CAROUSEL ROW
// ==========================================

@Composable
fun StoriesRow(
    currentUser: UserEntity,
    stories: List<StoryEntity>,
    allUsers: List<UserEntity>,
    drafts: List<StoryDraftEntity> = emptyList(),
    onAddStoryClick: () -> Unit,
    onViewUserStories: (userId: String) -> Unit,
    onOpenDrafts: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val usersMap = remember(allUsers) { allUsers.associateBy { it.userId } }
    val now = System.currentTimeMillis()
    val activeStories = remember(stories) { stories.filter { it.expiresAt > now } }

    val userStoriesMap = remember(activeStories) { activeStories.groupBy { it.userId } }
    val myStories = userStoriesMap[currentUser.userId] ?: emptyList()
    val hasMyStory = myStories.isNotEmpty()

    val otherUserIds = remember(userStoriesMap, currentUser.userId) {
        userStoriesMap.keys.filter { it != currentUser.userId }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "24-Hour Stories",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = "24 Hours",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "24h",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (drafts.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        modifier = Modifier.clickable { onOpenDrafts() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                Icons.Default.Drafts,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                "${drafts.size} Draft${if (drafts.size > 1) "s" else ""}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }
                }

                Text(
                    text = "${activeStories.size} active",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // My Story
            item(key = "my_story") {
                StoryAvatarItem(
                    isMyStory = true,
                    displayName = "Your Story",
                    userId = currentUser.userId,
                    avatarColorHex = currentUser.avatarColorHex,
                    hasStory = hasMyStory,
                    isUnviewed = false,
                    onClick = {
                        if (hasMyStory) {
                            onViewUserStories(currentUser.userId)
                        } else {
                            onAddStoryClick()
                        }
                    },
                    onAddBadgeClick = onAddStoryClick
                )
            }

            // Story Drafts item if user has saved drafts
            if (drafts.isNotEmpty()) {
                item(key = "story_drafts_carousel_item") {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(68.dp)
                            .clickable { onOpenDrafts() }
                            .testTag("story_drafts_item")
                    ) {
                        Box(
                            modifier = Modifier.size(64.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.tertiaryContainer)
                                    .border(2.dp, MaterialTheme.colorScheme.tertiary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EditNote,
                                    contentDescription = "Drafts",
                                    tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            // Badge
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .size(20.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${drafts.size}",
                                        color = MaterialTheme.colorScheme.onTertiary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Drafts (${drafts.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.tertiary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Contacts Stories
            items(otherUserIds, key = { it }) { userId ->
                val contactStories = userStoriesMap[userId] ?: emptyList()
                val user = usersMap[userId] ?: UserEntity(userId, userId.removePrefix("@"))
                val hasUnviewed = contactStories.any { !it.viewedByUserIds.split(",").contains(currentUser.userId) }

                StoryAvatarItem(
                    isMyStory = false,
                    displayName = user.displayName,
                    userId = user.userId,
                    avatarColorHex = user.avatarColorHex,
                    hasStory = true,
                    isUnviewed = hasUnviewed,
                    onClick = {
                        onViewUserStories(userId)
                    }
                )
            }
        }
    }
}

@Composable
fun StoryAvatarItem(
    isMyStory: Boolean,
    displayName: String,
    userId: String,
    avatarColorHex: String,
    hasStory: Boolean,
    isUnviewed: Boolean,
    onClick: () -> Unit,
    onAddBadgeClick: (() -> Unit)? = null
) {
    val ringBrush = when {
        isUnviewed -> Brush.sweepGradient(
            listOf(
                Color(0xFFFF512F),
                Color(0xFFDD2476),
                Color(0xFF8E2DE2),
                Color(0xFF00F260),
                Color(0xFFFF512F)
            )
        )
        hasStory -> Brush.linearGradient(
            listOf(
                MaterialTheme.colorScheme.outlineVariant,
                MaterialTheme.colorScheme.outline
            )
        )
        else -> Brush.linearGradient(
            listOf(
                MaterialTheme.colorScheme.surfaceVariant,
                MaterialTheme.colorScheme.surfaceVariant
            )
        )
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(68.dp)
            .clickable { onClick() }
            .testTag(if (isMyStory) "story_item_my" else "story_item_$userId")
    ) {
        Box(
            modifier = Modifier.size(64.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(ringBrush)
                    .padding(if (hasStory || isUnviewed) 2.5.dp else 1.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.background)
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(parseHexColor(avatarColorHex)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = displayName.take(1).uppercase(),
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (isMyStory) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.background)
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable { onAddBadgeClick?.invoke() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Story",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = if (isMyStory) "Your Story" else displayName,
            fontSize = 11.sp,
            fontWeight = if (isUnviewed) FontWeight.Bold else FontWeight.Normal,
            color = if (isUnviewed) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

// ==========================================
// 6. ENHANCED CREATE STORY DIALOG (WITH DRAFTS, MUSIC, MENTION, PHOTO/VIDEO)
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateStoryDialog(
    currentUser: UserEntity,
    allUsers: List<UserEntity>,
    drafts: List<StoryDraftEntity> = emptyList(),
    initialDraft: StoryDraftEntity? = null,
    onDismiss: () -> Unit,
    onSaveDraft: (
        draftId: Long,
        caption: String,
        backgroundGradient: String,
        textStyle: String,
        sticker: String?,
        musicTitle: String?,
        musicArtist: String?,
        mentionedUserIds: String,
        mediaType: String,
        mediaPresetId: String?
    ) -> Unit = { _, _, _, _, _, _, _, _, _, _ -> },
    onDeleteDraft: (draftId: Long) -> Unit = {},
    onPostStory: (
        caption: String,
        backgroundGradient: String,
        textStyle: String,
        sticker: String?,
        musicTitle: String?,
        musicArtist: String?,
        mentionedUserIds: String,
        mediaType: String,
        mediaPresetId: String?,
        fromDraftId: Long?
    ) -> Unit
) {
    val context = LocalContext.current
    var activeDraftId by remember { mutableStateOf<Long?>(initialDraft?.draftId) }
    var captionText by remember { mutableStateOf(initialDraft?.caption ?: "") }
    var selectedGradient by remember { mutableStateOf(initialDraft?.backgroundGradient ?: "SUNSET") }
    var selectedTextStyle by remember { mutableStateOf(initialDraft?.textStyle ?: "BOLD") }
    var selectedSticker by remember { mutableStateOf<String?>(initialDraft?.sticker ?: "✨") }
    var selectedMusic by remember {
        mutableStateOf<MusicTrack?>(
            if (initialDraft?.musicTitle != null) {
                CuratedMusic.tracks.find { it.title == initialDraft.musicTitle }
                    ?: MusicTrack(initialDraft.musicTitle, initialDraft.musicArtist ?: "", "3:00", "🎵", initialDraft.backgroundGradient)
            } else null
        )
    }
    var selectedMediaPreset by remember {
        mutableStateOf<MediaPreset?>(
            if (initialDraft?.mediaPresetId != null) {
                MediaCatalog.presets.find { it.id == initialDraft.mediaPresetId }
            } else null
        )
    }
    var mentionedUsers by remember {
        mutableStateOf<List<String>>(
            if (!initialDraft?.mentionedUserIds.isNullOrBlank()) {
                initialDraft!!.mentionedUserIds.split(",").filter { it.isNotBlank() }
            } else emptyList()
        )
    }

    var activeTab by remember { mutableIntStateOf(0) } // 0 = Text & Theme, 1 = Media (Photo/Video), 2 = Music & Mention
    var showMusicPicker by remember { mutableStateOf(false) }
    var showDraftsDialog by remember { mutableStateOf(false) }
    var showExitDialog by remember { mutableStateOf(false) }

    val stickers = listOf("✨", "🔥", "🚀", "☕", "🎉", "💡", "❤️", "🎧", "💻", "⭐", "🌴", "⚡")
    val gradientKeys = StoryGradients.gradients.keys.toList()

    val hasContentToSave = captionText.isNotBlank() || selectedMusic != null || selectedMediaPreset != null || (selectedSticker != null && selectedSticker != "✨")

    fun performSave(closeAfter: Boolean) {
        val gradientToSave = selectedMediaPreset?.gradientKey ?: selectedGradient
        val mediaTypeToSave = selectedMediaPreset?.type ?: "GRADIENT"
        val presetIdToSave = selectedMediaPreset?.id
        val musicTitleToSave = selectedMusic?.title
        val musicArtistToSave = selectedMusic?.artist
        val mentionsToSave = mentionedUsers.joinToString(",")

        onSaveDraft(
            activeDraftId ?: 0L,
            captionText.trim(),
            gradientToSave,
            selectedTextStyle,
            selectedSticker,
            musicTitleToSave,
            musicArtistToSave,
            mentionsToSave,
            mediaTypeToSave,
            presetIdToSave
        )
        Toast.makeText(context, "Story saved to Drafts! 💾", Toast.LENGTH_SHORT).show()
        if (closeAfter) {
            onDismiss()
        }
    }

    fun loadDraftData(draft: StoryDraftEntity) {
        activeDraftId = draft.draftId
        captionText = draft.caption
        selectedGradient = draft.backgroundGradient
        selectedTextStyle = draft.textStyle
        selectedSticker = draft.sticker
        selectedMusic = if (draft.musicTitle != null) {
            CuratedMusic.tracks.find { it.title == draft.musicTitle }
                ?: MusicTrack(draft.musicTitle, draft.musicArtist ?: "", "3:00", "🎵", draft.backgroundGradient)
        } else null
        selectedMediaPreset = if (draft.mediaPresetId != null) {
            MediaCatalog.presets.find { it.id == draft.mediaPresetId }
        } else null
        mentionedUsers = if (draft.mentionedUserIds.isNotBlank()) {
            draft.mentionedUserIds.split(",").filter { it.isNotBlank() }
        } else emptyList()

        showDraftsDialog = false
        Toast.makeText(context, "Draft loaded into editor 📝", Toast.LENGTH_SHORT).show()
    }

    BackHandler {
        if (showDraftsDialog) {
            showDraftsDialog = false
        } else if (showMusicPicker) {
            showMusicPicker = false
        } else if (hasContentToSave) {
            showExitDialog = true
        } else {
            onDismiss()
        }
    }

    Dialog(
        onDismissRequest = {
            if (hasContentToSave) {
                showExitDialog = true
            } else {
                onDismiss()
            }
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Create 24h Story", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (activeDraftId != null) "Editing Saved Draft 📝" else "Photo, Video, Music & Mentions",
                                fontSize = 12.sp,
                                color = if (activeDraftId != null) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            if (hasContentToSave) {
                                showExitDialog = true
                            } else {
                                onDismiss()
                            }
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    },
                    actions = {
                        // Drafts Manager Button
                        if (drafts.isNotEmpty()) {
                            IconButton(
                                onClick = { showDraftsDialog = true },
                                modifier = Modifier.testTag("view_drafts_button")
                            ) {
                                BadgedBox(
                                    badge = {
                                        Badge(
                                            containerColor = MaterialTheme.colorScheme.tertiary,
                                            contentColor = MaterialTheme.colorScheme.onTertiary
                                        ) {
                                            Text("${drafts.size}")
                                        }
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.Drafts,
                                        contentDescription = "View Drafts",
                                        tint = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                        }

                        // Save as Draft Button
                        FilledTonalButton(
                            onClick = { performSave(closeAfter = false) },
                            enabled = hasContentToSave,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .testTag("save_draft_button"),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.BookmarkBorder, contentDescription = "Save Draft", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Save Draft", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // Post 24h Story Button
                        Button(
                            onClick = {
                                onPostStory(
                                    captionText.trim(),
                                    selectedMediaPreset?.gradientKey ?: selectedGradient,
                                    selectedTextStyle,
                                    selectedSticker,
                                    selectedMusic?.title,
                                    selectedMusic?.artist,
                                    mentionedUsers.joinToString(","),
                                    selectedMediaPreset?.type ?: "GRADIENT",
                                    selectedMediaPreset?.id,
                                    activeDraftId
                                )
                                onDismiss()
                            },
                            enabled = captionText.isNotBlank() || selectedSticker != null || selectedMediaPreset != null,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("post_story_button")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Post", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Post 24h", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Active Draft banner if resuming from a draft
                if (activeDraftId != null) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.EditNote, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                                Text("Editing Saved Draft", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onTertiaryContainer)
                            }
                            TextButton(
                                onClick = {
                                    activeDraftId = null
                                    captionText = ""
                                    selectedSticker = "✨"
                                    selectedMusic = null
                                    selectedMediaPreset = null
                                    mentionedUsers = emptyList()
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("New Blank Story", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }
                    }
                }

                // Main Story Live Preview Canvas
                val effectiveGradient = selectedMediaPreset?.gradientKey ?: selectedGradient
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(24.dp))
                        .background(StoryGradients.getBrush(effectiveGradient))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Top Badges (24h timer & Media Type)
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Black.copy(alpha = 0.4f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.HourglassBottom, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                Text("24h Story", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (selectedMediaPreset != null) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Color.Black.copy(alpha = 0.4f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(selectedMediaPreset!!.iconEmoji, fontSize = 12.sp)
                                    Text(selectedMediaPreset!!.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Music Sticker Badge on Story
                    if (selectedMusic != null) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.Black.copy(alpha = 0.55f),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 34.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(selectedMusic!!.coverEmoji, fontSize = 14.sp)
                                Icon(Icons.Default.GraphicEq, contentDescription = "Music", tint = Color(0xFF00F260), modifier = Modifier.size(16.dp))
                                Text(
                                    text = "${selectedMusic!!.title} - ${selectedMusic!!.artist}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Story Center Content
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(20.dp)
                    ) {
                        selectedSticker?.let { sticker ->
                            Text(text = sticker, fontSize = 48.sp, modifier = Modifier.padding(bottom = 8.dp))
                        }

                        val fontStyle = when (selectedTextStyle) {
                            "BOLD" -> TextStyleConfig(FontWeight.ExtraBold, FontFamily.SansSerif, 22.sp, Color.White)
                            "CLASSIC" -> TextStyleConfig(FontWeight.Normal, FontFamily.Serif, 20.sp, Color.White)
                            "NEON" -> TextStyleConfig(FontWeight.Black, FontFamily.Monospace, 24.sp, Color(0xFFFFFF8D))
                            "TYPEWRITER" -> TextStyleConfig(FontWeight.Medium, FontFamily.Monospace, 18.sp, Color.White)
                            else -> TextStyleConfig(FontWeight.Bold, FontFamily.SansSerif, 22.sp, Color.White)
                        }

                        Text(
                            text = if (captionText.isNotBlank()) captionText else "Tap below to type your story...",
                            fontSize = fontStyle.size,
                            fontWeight = fontStyle.weight,
                            fontFamily = fontStyle.family,
                            color = if (captionText.isNotBlank()) fontStyle.color else Color.White.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center,
                            lineHeight = 28.sp
                        )

                        // Mention tags on story
                        if (mentionedUsers.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                mentionedUsers.forEach { tag ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = Color.Black.copy(alpha = 0.45f)
                                    ) {
                                        Text(
                                            text = tag,
                                            color = Color(0xFFFFD700),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Customization Tabs
                TabRow(
                    selectedTabIndex = activeTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp))
                ) {
                    Tab(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        text = { Text("Text & Style", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        text = { Text("Photo / Video", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.PermMedia, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = activeTab == 2,
                        onClick = { activeTab = 2 },
                        text = { Text("Music & Tag", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tab Content Panels
                when (activeTab) {
                    0 -> {
                        // Text & Theme Tab
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = captionText,
                                onValueChange = { if (it.length <= 200) captionText = it },
                                placeholder = { Text("Story caption...") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                maxLines = 2
                            )

                            // Sticker Row
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(stickers) { s ->
                                    val sel = selectedSticker == s
                                    Surface(
                                        shape = CircleShape,
                                        color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clickable { selectedSticker = if (sel) null else s }
                                    ) {
                                        Box(contentAlignment = Alignment.Center) { Text(s, fontSize = 18.sp) }
                                    }
                                }
                            }

                            // Gradient Selector
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(gradientKeys) { key ->
                                    val isSel = selectedGradient == key && selectedMediaPreset == null
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(StoryGradients.getBrush(key))
                                            .border(if (isSel) 2.5.dp else 0.dp, if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent, CircleShape)
                                            .clickable {
                                                selectedGradient = key
                                                selectedMediaPreset = null
                                            }
                                    )
                                }
                            }
                        }
                    }
                    1 -> {
                        // Photo & Video Presets Tab
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Select Aesthetic Photo / Video Preset:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(MediaCatalog.presets) { preset ->
                                    val isSelected = selectedMediaPreset?.id == preset.id
                                    Card(
                                        modifier = Modifier
                                            .width(130.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .clickable {
                                                selectedMediaPreset = if (isSelected) null else preset
                                            },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(preset.iconEmoji, fontSize = 28.sp)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(preset.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center)
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = if (preset.type == "VIDEO") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
                                                modifier = Modifier.padding(top = 4.dp)
                                            ) {
                                                Text(
                                                    text = preset.type,
                                                    color = Color.White,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        // Music & Mentions Tab
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Music Row
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { showMusicPicker = true },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Column {
                                            Text(
                                                text = if (selectedMusic != null) "${selectedMusic!!.title} - ${selectedMusic!!.artist}" else "Attach Music / Song 🎵",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = if (selectedMusic != null) "Tap to change song" else "Search & add trending tracks",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    if (selectedMusic != null) {
                                        IconButton(onClick = { selectedMusic = null }) {
                                            Icon(Icons.Default.Close, contentDescription = "Remove")
                                        }
                                    } else {
                                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                                    }
                                }
                            }

                            // Mention Contacts Row
                            Text("Mention / Tag Contacts (@):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(allUsers.filter { it.userId != currentUser.userId }) { user ->
                                    val isTagged = mentionedUsers.contains(user.userId)
                                    FilterChip(
                                        selected = isTagged,
                                        onClick = {
                                            mentionedUsers = if (isTagged) {
                                                mentionedUsers - user.userId
                                            } else {
                                                mentionedUsers + user.userId
                                            }
                                        },
                                        label = { Text("${user.displayName} (${user.userId})", fontSize = 11.sp) },
                                        leadingIcon = {
                                            if (isTagged) Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                            else Icon(Icons.Default.AlternateEmail, contentDescription = null, modifier = Modifier.size(14.dp))
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Music Selection Sheet
            if (showMusicPicker) {
                MusicPickerSheet(
                    onDismiss = { showMusicPicker = false },
                    onTrackSelected = { track ->
                        selectedMusic = track
                        showMusicPicker = false
                    }
                )
            }

            // Story Drafts Manager Dialog
            if (showDraftsDialog) {
                StoryDraftsDialog(
                    drafts = drafts,
                    onSelectDraft = { draft ->
                        loadDraftData(draft)
                    },
                    onDeleteDraft = { draftId ->
                        onDeleteDraft(draftId)
                        if (activeDraftId == draftId) {
                            activeDraftId = null
                        }
                    },
                    onPublishDirectly = { draft ->
                        onPostStory(
                            draft.caption,
                            draft.backgroundGradient,
                            draft.textStyle,
                            draft.sticker,
                            draft.musicTitle,
                            draft.musicArtist,
                            draft.mentionedUserIds,
                            draft.mediaType,
                            draft.mediaPresetId,
                            draft.draftId
                        )
                        showDraftsDialog = false
                        onDismiss()
                    },
                    onDismiss = { showDraftsDialog = false }
                )
            }

            // Exit Confirmation Dialog (Save Draft Prompt)
            if (showExitDialog) {
                AlertDialog(
                    onDismissRequest = { showExitDialog = false },
                    icon = { Icon(Icons.Default.Drafts, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                    title = { Text("Save Story as Draft?", fontWeight = FontWeight.Bold) },
                    text = {
                        Text(
                            "You have unsaved changes in your story creation. Would you like to save this story as a draft before closing, so you can edit and publish it to the 24h feed later?"
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showExitDialog = false
                                performSave(closeAfter = true)
                            }
                        ) {
                            Text("Save Draft & Close")
                        }
                    },
                    dismissButton = {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { showExitDialog = false }) {
                                Text("Keep Editing")
                            }
                            TextButton(
                                onClick = {
                                    showExitDialog = false
                                    onDismiss()
                                },
                                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) {
                                Text("Discard")
                            }
                        }
                    }
                )
            }
        }
    }
}

// ==========================================
// 6.1 SAVED STORY DRAFTS DIALOG
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryDraftsDialog(
    drafts: List<StoryDraftEntity>,
    onSelectDraft: (StoryDraftEntity) -> Unit,
    onDeleteDraft: (Long) -> Unit,
    onPublishDirectly: (StoryDraftEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val timeFormat = remember { SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Saved Story Drafts", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.tertiaryContainer
                            ) {
                                Text(
                                    "${drafts.size}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                )
            }
        ) { paddingValues ->
            if (drafts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            Icons.Default.Drafts,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            "No Saved Drafts",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "When creating a story, click 'Save Draft' to save your work and finish or publish it whenever you want.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(drafts, key = { it.draftId }) { draft ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp)),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Mini visual canvas preview
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(StoryGradients.getBrush(draft.backgroundGradient)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            draft.sticker?.let {
                                                Text(it, fontSize = 20.sp)
                                            }
                                            if (draft.mediaPresetId != null) {
                                                val preset = MediaCatalog.presets.find { it.id == draft.mediaPresetId }
                                                Text(preset?.iconEmoji ?: "📸", fontSize = 14.sp)
                                            }
                                        }
                                    }

                                    // Draft Details
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = if (draft.caption.isNotBlank()) draft.caption else "(No caption text)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )

                                        if (draft.musicTitle != null) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                                                Text(
                                                    "${draft.musicTitle} • ${draft.musicArtist ?: ""}",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }

                                        if (draft.mentionedUserIds.isNotBlank()) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(12.dp))
                                                Text(
                                                    draft.mentionedUserIds,
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.tertiary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }

                                        Text(
                                            text = "Saved ${timeFormat.format(Date(draft.lastModified))}",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                // Actions on this draft
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { onDeleteDraft(draft.draftId) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.DeleteOutline,
                                            contentDescription = "Delete Draft",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = { onSelectDraft(draft) },
                                            shape = RoundedCornerShape(14.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Resume Editing", fontSize = 12.sp)
                                        }

                                        Button(
                                            onClick = { onPublishDirectly(draft) },
                                            shape = RoundedCornerShape(14.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Publish", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 7. FULLSCREEN STORY VIEWER (WITH MUSIC & MENTION)
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryViewerDialog(
    targetUserId: String,
    stories: List<StoryEntity>,
    allUsers: List<UserEntity>,
    currentUser: UserEntity,
    onDismiss: () -> Unit,
    onDeleteStory: (storyId: Long) -> Unit,
    onMarkViewed: (StoryEntity) -> Unit,
    onSendQuickReply: (targetUserId: String, message: String) -> Unit,
    onOpenMentionedUserChat: ((userId: String) -> Unit)? = null
) {
    val usersMap = remember(allUsers) { allUsers.associateBy { it.userId } }
    val userStories = remember(stories, targetUserId) {
        stories.filter { it.userId == targetUserId }.sortedBy { it.timestamp }
    }

    if (userStories.isEmpty()) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }

    var currentIndex by remember { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var replyText by remember { mutableStateOf("") }
    var showViewersSheet by remember { mutableStateOf(false) }

    val currentStory = userStories.getOrNull(currentIndex) ?: userStories.first()
    val isMyStory = targetUserId == currentUser.userId
    val storyOwner = usersMap[targetUserId] ?: UserEntity(targetUserId, targetUserId.removePrefix("@"))

    LaunchedEffect(currentStory.storyId) {
        onMarkViewed(currentStory)
        progress = 0f
    }

    LaunchedEffect(currentIndex, isPaused) {
        if (!isPaused) {
            val stepDuration = 50L
            while (progress < 1f) {
                delay(stepDuration)
                if (!isPaused) {
                    progress += 0.01f
                }
            }
            if (currentIndex < userStories.size - 1) {
                currentIndex++
                progress = 0f
            } else {
                onDismiss()
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Story Canvas
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(StoryGradients.getBrush(currentStory.backgroundGradient))
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                isPaused = true
                                tryAwaitRelease()
                                isPaused = false
                            },
                            onTap = { offset ->
                                val screenWidth = size.width
                                if (offset.x < screenWidth * 0.35f) {
                                    if (currentIndex > 0) {
                                        currentIndex--
                                        progress = 0f
                                    }
                                } else {
                                    if (currentIndex < userStories.size - 1) {
                                        currentIndex++
                                        progress = 0f
                                    } else {
                                        onDismiss()
                                    }
                                }
                            }
                        )
                    }
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                // Center Story Content
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    currentStory.sticker?.let { sticker ->
                        Text(text = sticker, fontSize = 60.sp, modifier = Modifier.padding(bottom = 14.dp))
                    }

                    val fontStyle = when (currentStory.textStyle) {
                        "BOLD" -> TextStyleConfig(FontWeight.ExtraBold, FontFamily.SansSerif, 26.sp, Color.White)
                        "CLASSIC" -> TextStyleConfig(FontWeight.Normal, FontFamily.Serif, 22.sp, Color.White)
                        "NEON" -> TextStyleConfig(FontWeight.Black, FontFamily.Monospace, 28.sp, Color(0xFFFFFF8D))
                        "TYPEWRITER" -> TextStyleConfig(FontWeight.Medium, FontFamily.Monospace, 20.sp, Color.White)
                        else -> TextStyleConfig(FontWeight.Bold, FontFamily.SansSerif, 26.sp, Color.White)
                    }

                    if (currentStory.caption.isNotBlank()) {
                        Text(
                            text = currentStory.caption,
                            fontSize = fontStyle.size,
                            fontWeight = fontStyle.weight,
                            fontFamily = fontStyle.family,
                            color = fontStyle.color,
                            textAlign = TextAlign.Center,
                            lineHeight = 36.sp
                        )
                    }

                    // Mentioned Users Tags
                    if (currentStory.mentionedUserIds.isNotBlank()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        val tags = currentStory.mentionedUserIds.split(",").filter { it.isNotBlank() }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            tags.forEach { tag ->
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.Black.copy(alpha = 0.5f),
                                    modifier = Modifier.clickable {
                                        onOpenMentionedUserChat?.invoke(tag)
                                        onDismiss()
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = Color(0xFFFFD700), modifier = Modifier.size(13.dp))
                                        Text(tag, color = Color(0xFFFFD700), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Top Overlay
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, start = 16.dp, end = 16.dp)
            ) {
                // Progress Bars
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    userStories.forEachIndexed { index, _ ->
                        val segmentProgress = when {
                            index < currentIndex -> 1f
                            index == currentIndex -> progress
                            else -> 0f
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color.White.copy(alpha = 0.35f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(segmentProgress)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(Color.White)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Header Info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(parseHexColor(storyOwner.avatarColorHex)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(storyOwner.displayName.take(1).uppercase(), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(storyOwner.displayName, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Text(storyOwner.userId, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                            }
                            Text(
                                text = "${formatStoryTime(currentStory.timestamp)} • ⏳ Expires in ${calculateHoursRemaining(currentStory.expiresAt)}h",
                                color = Color.White.copy(alpha = 0.75f),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isMyStory) {
                            IconButton(onClick = {
                                onDeleteStory(currentStory.storyId)
                                if (userStories.size <= 1) onDismiss()
                                else if (currentIndex > 0) {
                                    currentIndex--
                                    progress = 0f
                                }
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.White)
                            }
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                // Music Audio Equalizer Pill
                if (currentStory.musicTitle != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.Black.copy(alpha = 0.5f),
                        modifier = Modifier.align(Alignment.Start)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.GraphicEq, contentDescription = "Playing Music", tint = Color(0xFF00F260), modifier = Modifier.size(14.dp))
                            Text(
                                text = "${currentStory.musicTitle} • ${currentStory.musicArtist ?: ""}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Bottom Overlay (Viewers or Reply)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp, vertical = 24.dp)
            ) {
                if (isMyStory) {
                    val viewers = currentStory.viewedByUserIds.split(",").filter { it.isNotBlank() }
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color.Black.copy(alpha = 0.6f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showViewersSheet = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Visibility, contentDescription = "Views", tint = Color.White)
                                Text("${viewers.size} Story Viewers", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            }
                            Text("View details", color = MaterialTheme.colorScheme.primaryContainer, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TextField(
                            value = replyText,
                            onValueChange = { replyText = it },
                            placeholder = { Text("Reply to ${storyOwner.displayName}'s story...", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(24.dp)),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Black.copy(alpha = 0.6f),
                                unfocusedContainerColor = Color.Black.copy(alpha = 0.4f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            singleLine = true
                        )

                        IconButton(
                            onClick = {
                                if (replyText.isNotBlank()) {
                                    onSendQuickReply(targetUserId, "Replied to story: \"${currentStory.caption}\"\n\n$replyText")
                                    replyText = ""
                                    onDismiss()
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send Reply", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }

            // Viewers Sheet
            if (showViewersSheet) {
                val viewersList = currentStory.viewedByUserIds.split(",").filter { it.isNotBlank() }
                ModalBottomSheet(onDismissRequest = { showViewersSheet = false }) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text("Story Views (${viewersList.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))

                        if (viewersList.isEmpty()) {
                            Text("No views yet. Story is visible for 24 hours.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            viewersList.forEach { viewerId ->
                                val vUser = usersMap[viewerId] ?: UserEntity(viewerId, viewerId.removePrefix("@"))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(parseHexColor(vUser.avatarColorHex)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(vUser.displayName.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text(vUser.displayName, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                        Text(vUser.userId, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }
            }
        }
    }
}

private data class TextStyleConfig(
    val weight: FontWeight,
    val family: FontFamily,
    val size: androidx.compose.ui.unit.TextUnit,
    val color: Color
)

fun formatStoryTime(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    val mins = diff / (1000 * 60)
    val hours = diff / (1000 * 60 * 60)
    return when {
        mins < 1 -> "Just now"
        mins < 60 -> "${mins}m ago"
        hours < 24 -> "${hours}h ago"
        else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(timestamp))
    }
}

fun calculateHoursRemaining(expiresAt: Long): Long {
    val diff = expiresAt - System.currentTimeMillis()
    val hours = diff / (1000 * 60 * 60)
    return if (hours > 0) hours else 1
}
