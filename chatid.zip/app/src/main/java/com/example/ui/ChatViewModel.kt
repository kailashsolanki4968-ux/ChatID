package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ChatEntity
import com.example.data.ChatRepository
import com.example.data.FollowRequestEntity
import com.example.data.FollowRequestWithUser
import com.example.data.MessageEntity
import com.example.data.UserEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CallState(
    val recipient: UserEntity,
    val isVideo: Boolean,
    val isRinging: Boolean = true,
    val isConnected: Boolean = false,
    val durationSeconds: Int = 0
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val repository = ChatRepository(db.chatDao())

    val currentUser = MutableStateFlow<UserEntity?>(null)
    val selectedTab = MutableStateFlow(0) // 0=Chats, 1=Search, 2=Contacts, 3=Profile

    val searchQuery = MutableStateFlow("")

    val activeChatId = MutableStateFlow<String?>(null)
    val activeRecipient = MutableStateFlow<UserEntity?>(null)

    val activeCall = MutableStateFlow<CallState?>(null)

    val isDarkMode = MutableStateFlow(false)
    val isLockedChatsUnlocked = MutableStateFlow(false)

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val chatsList: StateFlow<List<ChatEntity>> = currentUser
        .flatMapLatest { user ->
            if (user != null) {
                repository.getChatsForUser(user.userId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allUsersList: StateFlow<List<UserEntity>> = repository.getAllUsers()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val searchResults: StateFlow<List<UserEntity>> = searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) {
                repository.getAllUsers()
            } else {
                repository.searchUsers(query)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeChatMessages: StateFlow<List<MessageEntity>> = activeChatId
        .flatMapLatest { chatId ->
            if (chatId != null) {
                repository.getMessagesForChat(chatId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeChatEntity: StateFlow<ChatEntity?> = activeChatId
        .flatMapLatest { chatId ->
            if (chatId != null) {
                repository.observeChatById(chatId)
            } else {
                flowOf(null)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeFollowRequest: StateFlow<FollowRequestEntity?> = combine(currentUser, activeRecipient) { curr, recip ->
        if (curr != null && recip != null) {
            Pair(curr.userId, recip.userId)
        } else {
            null
        }
    }.flatMapLatest { pair ->
        if (pair != null) {
            repository.observeFollowRequest(pair.first, pair.second)
        } else {
            flowOf(null)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    @OptIn(ExperimentalCoroutinesApi::class)
    val incomingFollowRequests: StateFlow<List<FollowRequestWithUser>> = currentUser.flatMapLatest { curr ->
        if (curr != null) {
            repository.observeIncomingFollowRequests(curr.userId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    @OptIn(ExperimentalCoroutinesApi::class)
    val outgoingFollowRequests: StateFlow<List<FollowRequestWithUser>> = currentUser.flatMapLatest { curr ->
        if (curr != null) {
            repository.observeOutgoingFollowRequests(curr.userId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun loginOrRegister(userId: String, displayName: String, bio: String) {
        viewModelScope.launch {
            val user = repository.registerOrLoginUser(userId, displayName, bio)
            currentUser.value = user
        }
    }

    fun switchAccount(userId: String) {
        viewModelScope.launch {
            val user = repository.getUser(userId)
            if (user != null) {
                currentUser.value = user
                activeChatId.value = null
                activeRecipient.value = null
            }
        }
    }

    fun openChatWith(targetUserId: String) {
        val curr = currentUser.value ?: return
        viewModelScope.launch {
            val formattedTarget = ChatRepository.formatUserId(targetUserId)
            var targetUser = repository.getUser(formattedTarget)
            if (targetUser == null) {
                // If user doesn't exist, create a dynamic profile for this ID so search can immediately message anyone!
                targetUser = repository.registerOrLoginUser(
                    rawUserId = formattedTarget,
                    displayName = formattedTarget.removePrefix("@").replaceFirstChar { it.uppercase() },
                    bio = "Hey there! I am using ChatID."
                )
            }
            val chat = repository.getOrCreateChat(curr.userId, targetUser.userId)
            activeChatId.value = chat.chatId
            activeRecipient.value = targetUser
            repository.markAsRead(chat.chatId, curr.userId)
        }
    }

    fun closeActiveChat() {
        activeChatId.value = null
        activeRecipient.value = null
    }

    fun sendMessage(content: String, type: String = "TEXT", fileUri: String? = null) {
        val curr = currentUser.value ?: return
        val target = activeRecipient.value ?: return
        if (content.isBlank() && type == "TEXT" && fileUri == null) return

        viewModelScope.launch {
            repository.sendMessage(
                senderId = curr.userId,
                receiverId = target.userId,
                content = content,
                type = type,
                fileUri = fileUri
            )
        }
    }

    fun addReaction(messageId: Long, reaction: String?) {
        viewModelScope.launch {
            repository.addReaction(messageId, reaction)
        }
    }

    fun updateProfile(displayName: String, bio: String) {
        val curr = currentUser.value ?: return
        viewModelScope.launch {
            repository.updateUserProfile(curr.userId, displayName, bio)
            currentUser.value = curr.copy(displayName = displayName, bio = bio)
        }
    }

    fun startCall(recipient: UserEntity, isVideo: Boolean) {
        activeCall.value = CallState(
            recipient = recipient,
            isVideo = isVideo,
            isRinging = true
        )
    }

    fun endCall() {
        activeCall.value = null
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun toggleDarkMode() {
        isDarkMode.value = !isDarkMode.value
    }

    /**
     * Attempts to edit a message.
     * Enforces strict 10-minute (600,000ms) limit from creation timestamp.
     */
    fun editMessage(message: MessageEntity, newContent: String, onResult: (success: Boolean, message: String) -> Unit) {
        if (newContent.isBlank()) return
        val now = System.currentTimeMillis()
        val limitMs = 10 * 60 * 1000L // 10 minutes
        if (now - message.timestamp > limitMs) {
            onResult(false, "Cannot edit: 10 minute time limit has expired!")
            return
        }
        viewModelScope.launch {
            repository.editMessage(message.messageId, newContent)
            onResult(true, "Message updated!")
        }
    }

    fun deleteMessage(messageId: Long) {
        viewModelScope.launch {
            repository.deleteMessage(messageId)
        }
    }

    fun setChatLock(chatId: String, isLocked: Boolean, pin: String? = "1234") {
        viewModelScope.launch {
            repository.setChatLockState(chatId, isLocked, pin)
        }
    }

    fun blockUser(targetUserId: String, isBlocked: Boolean = true) {
        viewModelScope.launch {
            repository.setUserBlockState(targetUserId, isBlocked)
        }
    }

    fun togglePublicProfile(isPublic: Boolean) {
        val curr = currentUser.value ?: return
        viewModelScope.launch {
            repository.setUserPrivacyState(curr.userId, isPublic)
            currentUser.value = curr.copy(isPublicProfile = isPublic)
        }
    }

    fun deleteChat(chatId: String) {
        viewModelScope.launch {
            repository.deleteChat(chatId)
            if (activeChatId.value == chatId) {
                closeActiveChat()
            }
        }
    }

    // --- Follow Requests Actions ---
    fun sendFollowRequest(targetUserId: String) {
        val curr = currentUser.value ?: return
        viewModelScope.launch {
            repository.sendFollowRequest(curr.userId, targetUserId)
        }
    }

    fun acceptFollowRequest(targetUserId: String) {
        val curr = currentUser.value ?: return
        viewModelScope.launch {
            repository.acceptFollowRequest(curr.userId, targetUserId)
        }
    }

    fun declineFollowRequest(targetUserId: String) {
        val curr = currentUser.value ?: return
        viewModelScope.launch {
            repository.declineFollowRequest(curr.userId, targetUserId)
        }
    }

    val activeStories: StateFlow<List<com.example.data.StoryEntity>> = repository.observeActiveStories()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeNotes: StateFlow<List<com.example.data.NoteEntity>> = repository.observeActiveNotes()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val storyDrafts: StateFlow<List<com.example.data.StoryDraftEntity>> = currentUser
        .flatMapLatest { user ->
            if (user != null) {
                repository.getStoryDraftsForUser(user.userId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun saveStoryDraft(
        draftId: Long = 0,
        caption: String,
        backgroundGradient: String = "SUNSET",
        textStyle: String = "BOLD",
        sticker: String? = null,
        musicTitle: String? = null,
        musicArtist: String? = null,
        mentionedUserIds: String = "",
        mediaType: String = "GRADIENT",
        mediaPresetId: String? = null
    ) {
        val curr = currentUser.value ?: return
        viewModelScope.launch {
            repository.saveStoryDraft(
                draftId = draftId,
                userId = curr.userId,
                caption = caption,
                backgroundGradient = backgroundGradient,
                textStyle = textStyle,
                sticker = sticker,
                musicTitle = musicTitle,
                musicArtist = musicArtist,
                mentionedUserIds = mentionedUserIds,
                mediaType = mediaType,
                mediaPresetId = mediaPresetId
            )
        }
    }

    fun deleteStoryDraft(draftId: Long) {
        viewModelScope.launch {
            repository.deleteStoryDraft(draftId)
        }
    }

    fun postStory(
        caption: String,
        backgroundGradient: String = "SUNSET",
        textStyle: String = "BOLD",
        sticker: String? = null,
        musicTitle: String? = null,
        musicArtist: String? = null,
        mentionedUserIds: String = "",
        mediaType: String = "GRADIENT",
        mediaPresetId: String? = null
    ) {
        val curr = currentUser.value ?: return
        if (caption.isBlank() && sticker == null && mediaPresetId == null) return
        viewModelScope.launch {
            repository.postStory(
                userId = curr.userId,
                caption = caption,
                backgroundGradient = backgroundGradient,
                textStyle = textStyle,
                sticker = sticker,
                musicTitle = musicTitle,
                musicArtist = musicArtist,
                mentionedUserIds = mentionedUserIds,
                mediaType = mediaType,
                mediaPresetId = mediaPresetId
            )
        }
    }

    fun deleteStory(storyId: Long) {
        viewModelScope.launch {
            repository.deleteStory(storyId)
        }
    }

    fun markStoryAsViewed(story: com.example.data.StoryEntity) {
        val curr = currentUser.value ?: return
        viewModelScope.launch {
            repository.markStoryAsViewed(story, curr.userId)
        }
    }

    fun postNote(text: String, musicTitle: String? = null, musicArtist: String? = null) {
        val curr = currentUser.value ?: return
        if (text.isBlank() && musicTitle == null) return
        viewModelScope.launch {
            repository.postNote(
                userId = curr.userId,
                text = text.trim(),
                musicTitle = musicTitle,
                musicArtist = musicArtist
            )
        }
    }

    fun deleteNote() {
        val curr = currentUser.value ?: return
        viewModelScope.launch {
            repository.deleteNote(curr.userId)
        }
    }

    fun updateChatWallpaper(wallpaperKey: String) {
        val chatId = activeChatId.value ?: return
        viewModelScope.launch {
            repository.updateChatWallpaper(chatId, wallpaperKey)
        }
    }
}
