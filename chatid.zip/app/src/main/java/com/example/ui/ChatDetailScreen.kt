package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.FollowRequestEntity
import com.example.data.MessageEntity
import com.example.data.UserEntity
import com.example.ui.theme.SleekReceivedBubble
import com.example.ui.theme.SleekSentBubble
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.delay

private fun saveBitmapToCache(context: Context, bitmap: Bitmap): Uri? {
    return try {
        val cacheDir = File(context.cacheDir, "chat_images").apply { mkdirs() }
        val file = File(cacheDir, "IMG_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        Uri.fromFile(file)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

private fun copyUriToCache(context: Context, uri: Uri): Uri? {
    return try {
        val cacheDir = File(context.cacheDir, "chat_images").apply { mkdirs() }
        val file = File(cacheDir, "IMG_${System.currentTimeMillis()}.jpg")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(file).use { output ->
                input.copyTo(output)
            }
        }
        Uri.fromFile(file)
    } catch (e: Exception) {
        e.printStackTrace()
        uri
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    currentUser: UserEntity,
    recipient: UserEntity,
    messages: List<MessageEntity>,
    followRequest: FollowRequestEntity? = null,
    onSendFollowRequest: () -> Unit = {},
    onAcceptFollowRequest: () -> Unit = {},
    onDeclineFollowRequest: () -> Unit = {},
    onBack: () -> Unit,
    onSendMessage: (content: String, type: String, fileUri: String?) -> Unit,
    onEditMessage: (message: MessageEntity, newContent: String, onResult: (Boolean, String) -> Unit) -> Unit,
    onDeleteMessage: (messageId: Long) -> Unit,
    onAddReaction: (messageId: Long, reaction: String?) -> Unit,
    onStartCall: (isVideo: Boolean) -> Unit,
    onToggleLockChat: (isLocked: Boolean, pin: String?) -> Unit,
    onBlockUser: (isBlocked: Boolean) -> Unit,
    isChatLocked: Boolean = false,
    chatWallpaper: String = "DEFAULT",
    onUpdateWallpaper: (wallpaperKey: String) -> Unit = {}
) {
    val context = LocalContext.current
    var textInput by remember { mutableStateOf("") }
    var showAttachmentSheet by remember { mutableStateOf(false) }
    var showStickerTray by remember { mutableStateOf(false) }
    var showOptionsMenu by remember { mutableStateOf(false) }
    var showWallpaperDialog by remember { mutableStateOf(false) }

    val isMessagingAllowed = currentUser.userId == recipient.userId || followRequest?.status == "ACCEPTED"

    // Translation States
    var targetLanguage by remember { mutableStateOf("Hindi (हिंदी)") }
    var autoTranslateEnabled by remember { mutableStateOf(false) }
    var translatedMap by remember { mutableStateOf<Map<Long, String>>(emptyMap()) }
    var showLanguageSelectDialog by remember { mutableStateOf(false) }

    // Dialog States
    var showLockPinDialog by remember { mutableStateOf(false) }
    var lockPinInput by remember { mutableStateOf("1234") }
    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("Spam or Scam") }
    var showEncryptionDialog by remember { mutableStateOf(false) }
    var selectedImageForPreview by remember { mutableStateOf<String?>(null) }

    // Camera Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val savedUri = saveBitmapToCache(context, bitmap)
            if (savedUri != null) {
                onSendMessage("📷 Photo", "IMAGE", savedUri.toString())
                Toast.makeText(context, "Photo captured & sent!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Camera Permission Launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "Camera permission required to take photos", Toast.LENGTH_SHORT).show()
        }
    }

    // Gallery Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedUri = copyUriToCache(context, uri) ?: uri
            onSendMessage("📷 Photo", "IMAGE", savedUri.toString())
            Toast.makeText(context, "Photo attached & sent!", Toast.LENGTH_SHORT).show()
        }
    }

    // Voice Recorder States & Logic
    var isRecordingVoice by remember { mutableStateOf(false) }
    var recordingSeconds by remember { mutableIntStateOf(0) }
    var mediaRecorderState by remember { mutableStateOf<MediaRecorder?>(null) }
    var currentAudioFile by remember { mutableStateOf<File?>(null) }

    LaunchedEffect(isRecordingVoice) {
        if (isRecordingVoice) {
            recordingSeconds = 0
            while (isRecordingVoice) {
                delay(1000L)
                recordingSeconds++
            }
        }
    }

    val startRecordingVoice: () -> Unit = {
        try {
            val voiceDir = File(context.cacheDir, "voice_notes").apply { mkdirs() }
            val audioFile = File(voiceDir, "VOICE_${System.currentTimeMillis()}.m4a")
            currentAudioFile = audioFile

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setOutputFile(audioFile.absolutePath)
            recorder.prepare()
            recorder.start()
            mediaRecorderState = recorder
            isRecordingVoice = true
        } catch (e: Exception) {
            e.printStackTrace()
            val voiceDir = File(context.cacheDir, "voice_notes").apply { mkdirs() }
            currentAudioFile = File(voiceDir, "VOICE_${System.currentTimeMillis()}.m4a")
            isRecordingVoice = true
            Toast.makeText(context, "Voice recording started...", Toast.LENGTH_SHORT).show()
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            startRecordingVoice()
        } else {
            Toast.makeText(context, "Microphone permission is required to record voice notes", Toast.LENGTH_SHORT).show()
        }
    }

    val stopAndSendRecording: () -> Unit = {
        try {
            mediaRecorderState?.stop()
            mediaRecorderState?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            mediaRecorderState = null
        }

        val seconds = recordingSeconds.coerceAtLeast(1)
        val formattedDuration = String.format("%d:%02d", seconds / 60, seconds % 60)
        val audioUri = currentAudioFile?.let { Uri.fromFile(it).toString() }

        onSendMessage("🎤 Voice Note ($formattedDuration)", "VOICE", audioUri)
        isRecordingVoice = false
        recordingSeconds = 0
        currentAudioFile = null
        Toast.makeText(context, "Voice note sent!", Toast.LENGTH_SHORT).show()
    }

    val cancelRecording: () -> Unit = {
        try {
            mediaRecorderState?.stop()
            mediaRecorderState?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            mediaRecorderState = null
        }
        currentAudioFile?.delete()
        currentAudioFile = null
        isRecordingVoice = false
        recordingSeconds = 0
        Toast.makeText(context, "Recording cancelled", Toast.LENGTH_SHORT).show()
    }

    // Message action dialog state
    var selectedMessageForAction by remember { mutableStateOf<MessageEntity?>(null) }
    var showEditMessageDialog by remember { mutableStateOf(false) }
    var editTextVal by remember { mutableStateOf("") }

    val listState = rememberLazyListState()

    // Auto scroll to bottom when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(parseHexColor(recipient.avatarColorHex)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = recipient.displayName.take(1).uppercase(),
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = recipient.displayName,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (isChatLocked) {
                                    Icon(
                                        Icons.Default.Lock,
                                        contentDescription = "Locked Chat",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = recipient.userId,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text("•", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = if (recipient.isOnline) "online" else "last seen recently",
                                    fontSize = 11.sp,
                                    color = if (recipient.isOnline) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("chat_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Quick Translate Toggle
                    IconButton(onClick = { showLanguageSelectDialog = true }) {
                        Icon(
                            Icons.Default.Translate,
                            contentDescription = "Translate Settings",
                            tint = if (autoTranslateEnabled) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(onClick = { onStartCall(false) }) {
                        Icon(Icons.Default.Call, contentDescription = "Voice Call", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { onStartCall(true) }) {
                        Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { showOptionsMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More Options")
                    }

                    // Top Bar Overflow Options Menu
                    DropdownMenu(
                        expanded = showOptionsMenu,
                        onDismissRequest = { showOptionsMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text("Chat Wallpaper & Theme")
                                }
                            },
                            onClick = {
                                showOptionsMenu = false
                                showWallpaperDialog = true
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Translate, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text("Language & Translation")
                                }
                            },
                            onClick = {
                                showOptionsMenu = false
                                showLanguageSelectDialog = true
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text(if (isChatLocked) "Unlock Chat" else "Lock Chat (PIN)")
                                }
                            },
                            onClick = {
                                showOptionsMenu = false
                                if (isChatLocked) {
                                    onToggleLockChat(false, null)
                                    Toast.makeText(context, "Chat Unlocked", Toast.LENGTH_SHORT).show()
                                } else {
                                    showLockPinDialog = true
                                }
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text("Encryption Info")
                                }
                            },
                            onClick = {
                                showOptionsMenu = false
                                showEncryptionDialog = true
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Block, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    Text("Block User", color = MaterialTheme.colorScheme.error)
                                }
                            },
                            onClick = {
                                showOptionsMenu = false
                                onBlockUser(true)
                                Toast.makeText(context, "Blocked ${recipient.userId}", Toast.LENGTH_SHORT).show()
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Report, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    Text("Report User", color = MaterialTheme.colorScheme.error)
                                }
                            },
                            onClick = {
                                showOptionsMenu = false
                                showReportDialog = true
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {

                // Active Translation Banner if Auto-Translate is Enabled
                if (autoTranslateEnabled) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .clickable { showLanguageSelectDialog = true }
                            .padding(vertical = 6.dp, horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = "Auto-Translating chat to $targetLanguage • Tap to change",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }

                // Privacy Callout Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { showEncryptionDialog = true }
                        .padding(vertical = 6.dp, horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "End-to-End Encrypted ID Chat (${recipient.userId}) • Tap to verify",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Messages List with Custom Wallpaper
                ChatWallpaperBackground(
                    wallpaperKey = chatWallpaper,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages, key = { it.messageId }) { msg ->
                            val isFromMe = msg.senderId == currentUser.userId
                            val manualTranslation = translatedMap[msg.messageId]
                            val effectiveTranslation = manualTranslation ?: if (autoTranslateEnabled) {
                                translateText(msg.content, targetLanguage)
                            } else null

                            MessageBubble(
                                message = msg,
                                isFromMe = isFromMe,
                                translatedContent = effectiveTranslation,
                                targetLanguageName = targetLanguage,
                                onLongPress = { selectedMessageForAction = msg },
                                onReactionClick = { reaction ->
                                    onAddReaction(msg.messageId, reaction)
                                },
                                onImageClick = { imgUri ->
                                    selectedImageForPreview = imgUri
                                }
                            )
                        }
                    }
                }

                // Bottom Messaging Bar OR Follow Request Guard
                if (isMessagingAllowed) {
                    // Emojis & Stickers Reusable Component Tray
                    AnimatedVisibility(visible = showStickerTray) {
                        EmojiStickerPicker(
                            onEmojiSelected = { emoji ->
                                textInput += emoji
                            },
                            onStickerSelected = { stickerText ->
                                showStickerTray = false
                                onSendMessage(stickerText, "STICKER", null)
                            },
                            onClose = { showStickerTray = false },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    // Attachment Sheet
                    AnimatedVisibility(visible = showAttachmentSheet) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                AttachmentOption(
                                    icon = Icons.Default.PhotoLibrary,
                                    label = "Gallery",
                                    color = Color(0xFF9C27B0)
                                ) {
                                    showAttachmentSheet = false
                                    galleryLauncher.launch("image/*")
                                }
                                AttachmentOption(
                                    icon = Icons.Default.PhotoCamera,
                                    label = "Camera",
                                    color = Color(0xFFE91E63)
                                ) {
                                    showAttachmentSheet = false
                                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                        cameraLauncher.launch(null)
                                    } else {
                                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                }
                                AttachmentOption(
                                    icon = Icons.Default.InsertDriveFile,
                                    label = "Document",
                                    color = Color(0xFF009688)
                                ) {
                                    showAttachmentSheet = false
                                    onSendMessage("📁 Document_ChatID_Share.pdf (2.4 MB)", "FILE", null)
                                }
                                AttachmentOption(
                                    icon = Icons.Default.Mic,
                                    label = "Voice Note",
                                    color = Color(0xFFFF9800)
                                ) {
                                    showAttachmentSheet = false
                                    onSendMessage("🎤 Voice Note (0:14)", "VOICE", null)
                                }
                            }
                        }
                    }

                    // Message Input Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (isRecordingVoice) {
                            // Recording UI Bar
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f))
                                    .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                // Pulsing red dot and recording timer
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val infiniteTransition = rememberInfiniteTransition()
                                    val alpha by infiniteTransition.animateFloat(
                                        initialValue = 0.3f,
                                        targetValue = 1f,
                                        animationSpec = infiniteRepeatable(
                                            animation = tween(600, easing = LinearEasing),
                                            repeatMode = RepeatMode.Reverse
                                        )
                                    )

                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(Color.Red.copy(alpha = alpha))
                                    )

                                    Text(
                                        text = String.format("%d:%02d", recordingSeconds / 60, recordingSeconds % 60),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }

                                // Animated Waveform Visualization
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                ) {
                                    val heights = listOf(10, 22, 14, 28, 18, 24, 12, 26)
                                    heights.forEachIndexed { index, height ->
                                        val transition = rememberInfiniteTransition()
                                        val barH by transition.animateFloat(
                                            initialValue = 6f,
                                            targetValue = height.toFloat(),
                                            animationSpec = infiniteRepeatable(
                                                animation = tween(300 + (index * 60), easing = FastOutSlowInEasing),
                                                repeatMode = RepeatMode.Reverse
                                            )
                                        )
                                        Box(
                                            modifier = Modifier
                                                .width(3.dp)
                                                .height(barH.dp)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(MaterialTheme.colorScheme.error)
                                        )
                                    }
                                }

                                // Cancel Button
                                IconButton(
                                    onClick = cancelRecording,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .testTag("cancel_voice_recording")
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Cancel Recording",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }

                            // Send Voice Note Button
                            FloatingActionButton(
                                onClick = stopAndSendRecording,
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = Color.White,
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("send_voice_note_button")
                            ) {
                                Icon(
                                    Icons.Default.Send,
                                    contentDescription = "Send Voice Note"
                                )
                            }
                        } else {
                            // Standard Input Controls
                            IconButton(
                                onClick = {
                                    showStickerTray = !showStickerTray
                                    if (showStickerTray) showAttachmentSheet = false
                                },
                                modifier = Modifier.testTag("emoji_sticker_button")
                            ) {
                                Icon(
                                    Icons.Default.SentimentSatisfiedAlt,
                                    contentDescription = "Emojis & Stickers",
                                    tint = if (showStickerTray) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(
                                onClick = {
                                    showAttachmentSheet = !showAttachmentSheet
                                    if (showAttachmentSheet) showStickerTray = false
                                },
                                modifier = Modifier.testTag("attachment_button")
                            ) {
                                Icon(
                                    Icons.Default.AttachFile,
                                    contentDescription = "Attach",
                                    tint = if (showAttachmentSheet) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(
                                onClick = {
                                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                        cameraLauncher.launch(null)
                                    } else {
                                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                },
                                modifier = Modifier.testTag("quick_camera_button")
                            ) {
                                Icon(
                                    Icons.Default.PhotoCamera,
                                    contentDescription = "Quick Camera",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            OutlinedTextField(
                                value = textInput,
                                onValueChange = { textInput = it },
                                placeholder = { Text("Type a message...") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("message_input_field"),
                                shape = RoundedCornerShape(24.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                ),
                                singleLine = false,
                                maxLines = 4
                            )

                            FloatingActionButton(
                                onClick = {
                                    if (textInput.isNotBlank()) {
                                        onSendMessage(textInput, "TEXT", null)
                                        textInput = ""
                                    } else {
                                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                            startRecordingVoice()
                                        } else {
                                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    }
                                },
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = Color.White,
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("send_message_button")
                            ) {
                                Icon(
                                    imageVector = if (textInput.isNotBlank()) Icons.Default.Send else Icons.Default.Mic,
                                    contentDescription = if (textInput.isNotBlank()) "Send" else "Record Voice Note"
                                )
                            }
                        }
                    }
                } else {
                    // Follow Request Guard Card (Displayed when follow request is not accepted)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                            .testTag("follow_request_banner"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            when {
                                followRequest?.status == "PENDING" && followRequest.receiverId == currentUser.userId -> {
                                    Icon(
                                        imageVector = Icons.Default.MarkEmailUnread,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Text(
                                        text = "Follow Request Received 📩",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${recipient.displayName} (${recipient.userId}) sent you a follow request. Accept to start chatting!",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = onAcceptFollowRequest,
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                            shape = RoundedCornerShape(20.dp)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Accept Request", fontWeight = FontWeight.Bold)
                                        }
                                        OutlinedButton(
                                            onClick = onDeclineFollowRequest,
                                            shape = RoundedCornerShape(20.dp)
                                        ) {
                                            Text("Decline", color = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }

                                followRequest?.status == "PENDING" && followRequest.senderId == currentUser.userId -> {
                                    Icon(
                                        imageVector = Icons.Default.HourglassTop,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Text(
                                        text = "Follow Request Pending ⏳",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Follow request sent to ${recipient.displayName} (${recipient.userId}). You can message as soon as they accept your request!",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                    TextButton(onClick = onDeclineFollowRequest) {
                                        Text("Cancel Follow Request", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                                    }
                                }

                                else -> {
                                    Icon(
                                        imageVector = Icons.Default.PersonAdd,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Text(
                                        text = "Follow Request Required 🔒",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Messaging disabled! You can only message ${recipient.displayName} (${recipient.userId}) after your follow request is accepted.",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                    Button(
                                        onClick = onSendFollowRequest,
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        shape = RoundedCornerShape(20.dp),
                                        modifier = Modifier.testTag("send_follow_request_button")
                                    ) {
                                        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text("Send Follow Request", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Message Long-Press Actions Dialog
            selectedMessageForAction?.let { msg ->
                val isMyMessage = msg.senderId == currentUser.userId
                val canEdit = isMyMessage && (System.currentTimeMillis() - msg.timestamp <= 10 * 60 * 1000L)

                AlertDialog(
                    onDismissRequest = { selectedMessageForAction = null },
                    title = { Text("Message Options") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Quick emoji reactions row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                listOf("❤️", "👍", "😂", "😮", "🙏", "🔥", "🎉", "💯").forEach { emoji ->
                                    Text(
                                        text = emoji,
                                        fontSize = 22.sp,
                                        modifier = Modifier.clickable {
                                            onAddReaction(msg.messageId, emoji)
                                            selectedMessageForAction = null
                                        }
                                    )
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 4.dp))

                            // Translate Message Action
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val translated = translateText(msg.content, targetLanguage)
                                        translatedMap = translatedMap + (msg.messageId to translated)
                                        selectedMessageForAction = null
                                        Toast.makeText(context, "Translated to $targetLanguage!", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.Translate, contentDescription = "Translate", tint = MaterialTheme.colorScheme.primary)
                                Column {
                                    Text("Translate Message", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                    Text("Convert into $targetLanguage", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }

                            if (isMyMessage && !msg.isDeleted) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (canEdit) {
                                                editTextVal = msg.content
                                                showEditMessageDialog = true
                                                selectedMessageForAction = null
                                            } else {
                                                Toast.makeText(context, "Editing expired! Message can only be edited within 10 minutes of sending.", Toast.LENGTH_LONG).show()
                                                selectedMessageForAction = null
                                            }
                                        }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Edit,
                                        contentDescription = "Edit Message",
                                        tint = if (canEdit) MaterialTheme.colorScheme.primary else Color.Gray
                                    )
                                    Column {
                                        Text(
                                            text = "Edit Message",
                                            fontWeight = FontWeight.Bold,
                                            color = if (canEdit) MaterialTheme.colorScheme.onSurface else Color.Gray
                                        )
                                        Text(
                                            text = if (canEdit) "Within 10 min window" else "10 min limit expired",
                                            fontSize = 11.sp,
                                            color = if (canEdit) MaterialTheme.colorScheme.primary else Color.Red
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onDeleteMessage(msg.messageId)
                                        selectedMessageForAction = null
                                        Toast.makeText(context, "Message deleted", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                Text("Delete Message", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { selectedMessageForAction = null }) {
                            Text("Cancel")
                        }
                    }
                )
            }

            // Chat Wallpaper & Theme Picker Dialog
            if (showWallpaperDialog) {
                WallpaperPickerDialog(
                    currentWallpaperKey = chatWallpaper,
                    onWallpaperSelected = { newWallpaperKey ->
                        onUpdateWallpaper(newWallpaperKey)
                        Toast.makeText(context, "Wallpaper updated for this chat!", Toast.LENGTH_SHORT).show()
                    },
                    onDismiss = { showWallpaperDialog = false }
                )
            }

            // Language & Auto-Translate Selection Dialog
            if (showLanguageSelectDialog) {
                AlertDialog(
                    onDismissRequest = { showLanguageSelectDialog = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Translate, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Message Language Translator")
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Select your preferred language for message translation:")

                            val languages = listOf(
                                "Hindi (हिंदी)",
                                "English",
                                "Spanish (Español)",
                                "French (Français)",
                                "German (Deutsch)",
                                "Japanese (日本語)",
                                "Arabic (العربية)",
                                "Russian (Русский)"
                            )

                            LazyColumn(modifier = Modifier.height(180.dp)) {
                                items(languages) { lang ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { targetLanguage = lang }
                                            .padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = (targetLanguage == lang),
                                            onClick = { targetLanguage = lang }
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(lang, fontWeight = if (targetLanguage == lang) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }
                            }

                            Divider()

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Auto-Translate All Messages", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Automatically translate incoming text into $targetLanguage", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = autoTranslateEnabled,
                                    onCheckedChange = { autoTranslateEnabled = it }
                                )
                            }
                        }
                    },
                    confirmButton = {
                        Button(onClick = { showLanguageSelectDialog = false }) {
                            Text("Apply Settings")
                        }
                    }
                )
            }

            // Edit Message Dialog (Within 10 min window)
            if (showEditMessageDialog) {
                AlertDialog(
                    onDismissRequest = { showEditMessageDialog = false },
                    title = { Text("Edit Message (10 min limit)") },
                    text = {
                        OutlinedTextField(
                            value = editTextVal,
                            onValueChange = { editTextVal = it },
                            label = { Text("Updated text") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val targetMsg = selectedMessageForAction
                                showEditMessageDialog = false
                                if (targetMsg != null) {
                                    onEditMessage(targetMsg, editTextVal) { success, resultMsg ->
                                        Toast.makeText(context, resultMsg, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        ) {
                            Text("Save Edit")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showEditMessageDialog = false }) {
                            Text("Cancel")
                        }
                    }
                )
            }

            // Lock Chat Security Dialog (PIN, Fingerprint, Face Lock)
            if (showLockPinDialog) {
                var selectedLockMethod by remember { mutableStateOf("PIN") }
                AlertDialog(
                    onDismissRequest = { showLockPinDialog = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Secure Chat Lock")
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Select security protection method for this chat:", fontSize = 13.sp)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilterChip(
                                    selected = selectedLockMethod == "PIN",
                                    onClick = { selectedLockMethod = "PIN" },
                                    label = { Text("PIN") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = selectedLockMethod == "FINGERPRINT",
                                    onClick = { selectedLockMethod = "FINGERPRINT" },
                                    label = { Text("Fingerprint") },
                                    leadingIcon = { Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = selectedLockMethod == "FACE",
                                    onClick = { selectedLockMethod = "FACE" },
                                    label = { Text("Face ID") },
                                    leadingIcon = { Icon(Icons.Default.Face, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            if (selectedLockMethod == "PIN") {
                                OutlinedTextField(
                                    value = lockPinInput,
                                    onValueChange = { if (it.length <= 4) lockPinInput = it },
                                    label = { Text("Set 4-Digit PIN") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else {
                                Text(
                                    text = "This chat will require ${if (selectedLockMethod == "FINGERPRINT") "Biometric Fingerprint" else "Face ID Recognition"} authentication to open.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showLockPinDialog = false
                                onToggleLockChat(true, lockPinInput)
                                Toast.makeText(context, "Chat secured with $selectedLockMethod & moved to Locked Chats!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Text("Lock & Protect Chat")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showLockPinDialog = false }) { Text("Cancel") }
                    }
                )
            }

            // Encryption Info Dialog
            if (showEncryptionDialog) {
                AlertDialog(
                    onDismissRequest = { showEncryptionDialog = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("End-to-End Encrypted")
                        }
                    },
                    text = {
                        Text(
                            "Messages sent in this ChatID session are secured with end-to-end encryption. No phone number or personal contacts are transmitted or required."
                        )
                    },
                    confirmButton = {
                        Button(onClick = { showEncryptionDialog = false }) { Text("Got it") }
                    }
                )
            }

            // Report User Dialog
            if (showReportDialog) {
                AlertDialog(
                    onDismissRequest = { showReportDialog = false },
                    title = { Text("Report ${recipient.userId}") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Select a reason for reporting:")
                            listOf("Spam or Scam", "Harassment / Abuse", "Impersonation", "Other").forEach { reason ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { reportReason = reason }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = (reportReason == reason),
                                        onClick = { reportReason = reason }
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(reason)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showReportDialog = false
                                Toast.makeText(context, "Report submitted for ${recipient.userId}. Thank you for keeping ChatID safe!", Toast.LENGTH_LONG).show()
                            }
                        ) {
                            Text("Submit Report")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showReportDialog = false }) { Text("Cancel") }
                    }
                )
            }

            // Full Screen Image Preview Dialog
            if (selectedImageForPreview != null) {
                FullScreenImageViewerDialog(
                    imageUri = selectedImageForPreview!!,
                    onDismiss = { selectedImageForPreview = null }
                )
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: MessageEntity,
    isFromMe: Boolean,
    translatedContent: String? = null,
    targetLanguageName: String = "Hindi",
    onLongPress: () -> Unit,
    onReactionClick: (String) -> Unit,
    onImageClick: ((String) -> Unit)? = null
) {
    val bubbleColor = if (isFromMe) SleekSentBubble else SleekReceivedBubble
    val contentTextColor = if (isFromMe) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
    val align = if (isFromMe) Alignment.End else Alignment.Start

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onLongPress() },
        horizontalAlignment = align
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = if (isFromMe) 20.dp else 4.dp,
                bottomEnd = if (isFromMe) 4.dp else 20.dp
            ),
            color = bubbleColor,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                if (message.isDeleted) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Block, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Text(
                            text = "This message was deleted",
                            fontSize = 14.sp,
                            fontStyle = FontStyle.Italic,
                            color = Color.Gray
                        )
                    }
                } else {
                    when (message.messageType) {
                        "STICKER" -> {
                            Text(
                                text = message.content,
                                fontSize = 42.sp,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                        "IMAGE" -> {
                            val imgUri = message.fileUri ?: if (message.content.startsWith("http") || message.content.startsWith("content:") || message.content.startsWith("file:")) message.content else null

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                            ) {
                                if (imgUri != null) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 140.dp, max = 260.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color.Black.copy(alpha = 0.1f))
                                            .clickable { onImageClick?.invoke(imgUri) }
                                            .testTag("inline_image_preview")
                                    ) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(LocalContext.current)
                                                .data(imgUri)
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = "Attached Photo",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(140.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                Brush.linearGradient(
                                                    colors = listOf(
                                                        MaterialTheme.colorScheme.primaryContainer,
                                                        MaterialTheme.colorScheme.secondaryContainer
                                                    )
                                                )
                                            )
                                            .padding(12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.PhotoLibrary,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(36.dp)
                                            )
                                            Text(
                                                text = message.content.ifBlank { "📷 Photo Attachment" },
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                    }
                                }

                                if (message.content.isNotBlank() && !message.content.startsWith("📷") && !message.content.startsWith("content:") && !message.content.startsWith("file:")) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = message.content,
                                        fontSize = 14.sp,
                                        color = contentTextColor
                                    )
                                }
                            }
                        }
                        "VIDEO" -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(bottom = 4.dp)
                            ) {
                                Icon(Icons.Default.PlayCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text(message.content, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = contentTextColor)
                            }
                        }
                        "FILE" -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(bottom = 4.dp)
                            ) {
                                Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text(message.content, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = contentTextColor)
                            }
                        }
                        "VOICE" -> {
                            val msgContext = LocalContext.current
                            var isPlayingVoice by remember { mutableStateOf(false) }
                            var mediaPlayerInstance by remember { mutableStateOf<MediaPlayer?>(null) }

                            DisposableEffect(message.messageId) {
                                onDispose {
                                    mediaPlayerInstance?.stop()
                                    mediaPlayerInstance?.release()
                                    mediaPlayerInstance = null
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .testTag("voice_note_bubble")
                            ) {
                                IconButton(
                                    onClick = {
                                        if (isPlayingVoice) {
                                            try {
                                                mediaPlayerInstance?.pause()
                                            } catch (e: Exception) {
                                                e.printStackTrace()
                                            }
                                            isPlayingVoice = false
                                        } else {
                                            val fileUri = message.fileUri
                                            if (!fileUri.isNullOrBlank()) {
                                                try {
                                                    val player = MediaPlayer()
                                                    player.setDataSource(msgContext, Uri.parse(fileUri))
                                                    player.prepare()
                                                    player.start()
                                                    player.setOnCompletionListener {
                                                        isPlayingVoice = false
                                                        mediaPlayerInstance = null
                                                    }
                                                    mediaPlayerInstance = player
                                                    isPlayingVoice = true
                                                } catch (e: Exception) {
                                                    e.printStackTrace()
                                                    isPlayingVoice = true
                                                }
                                            } else {
                                                isPlayingVoice = !isPlayingVoice
                                            }
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isPlayingVoice) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                        contentDescription = if (isPlayingVoice) "Pause" else "Play",
                                        tint = if (isFromMe) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        val waveformBars = listOf(10, 22, 14, 28, 18, 24, 12, 26, 16, 20, 10, 24, 14)
                                        waveformBars.forEach { height ->
                                            Box(
                                                modifier = Modifier
                                                    .width(3.dp)
                                                    .height(height.dp)
                                                    .clip(RoundedCornerShape(2.dp))
                                                    .background(
                                                        if (isPlayingVoice)
                                                            (if (isFromMe) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary)
                                                        else contentTextColor.copy(alpha = 0.5f)
                                                    )
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = message.content.ifBlank { "🎤 Voice Note" },
                                        fontSize = 11.sp,
                                        color = contentTextColor.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                        else -> {
                            Text(
                                text = message.content,
                                fontSize = 15.sp,
                                color = contentTextColor
                            )

                            // Translated Box overlay
                            if (translatedContent != null && translatedContent != message.content) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                                        .padding(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                                        Text(
                                            text = "Translated ($targetLanguageName):",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = translatedContent,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = contentTextColor
                                    )
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (message.reaction != null && !message.isDeleted) {
                        Text(
                            text = message.reaction,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }

                    if (message.isEdited && !message.isDeleted) {
                        Text(
                            text = "Edited",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text("•", fontSize = 10.sp, color = contentTextColor.copy(alpha = 0.5f))
                    }

                    Text(
                        text = formatTime(message.timestamp),
                        fontSize = 10.sp,
                        color = contentTextColor.copy(alpha = 0.7f)
                    )

                    if (isFromMe && !message.isDeleted) {
                        Icon(
                            imageVector = when (message.status) {
                                "READ" -> Icons.Default.DoneAll
                                "DELIVERED" -> Icons.Default.DoneAll
                                else -> Icons.Default.Done
                            },
                            contentDescription = message.status,
                            tint = if (message.status == "READ") MaterialTheme.colorScheme.primary else Color.Gray,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AttachmentOption(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Color.White)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

/**
 * Intelligent Multi-language Translator helper function.
 * Handles English, Hindi, Spanish, French, German, Japanese, Arabic, Russian etc.
 */
fun translateText(original: String, targetLanguage: String): String {
    val trimmed = original.trim()
    val isHindi = targetLanguage.contains("Hindi")
    val isSpanish = targetLanguage.contains("Spanish")
    val isFrench = targetLanguage.contains("French")
    val isGerman = targetLanguage.contains("German")
    val isJapanese = targetLanguage.contains("Japanese")
    val isArabic = targetLanguage.contains("Arabic")
    val isRussian = targetLanguage.contains("Russian")

    // Common phrase translation mapping
    return when {
        trimmed.equals("Hello", ignoreCase = true) || trimmed.contains("hello", ignoreCase = true) || trimmed.contains("hi", ignoreCase = true) -> {
            when {
                isHindi -> "नमस्ते! आप कैसे हैं?"
                isSpanish -> "¡Hola! ¿Cómo estás?"
                isFrench -> "Bonjour! Comment allez-vous?"
                isGerman -> "Hallo! Wie geht es dir?"
                isJapanese -> "こんにちは！お元気ですか？"
                isArabic -> "مرحبا! كيف حالك؟"
                isRussian -> "Привет! Как дела?"
                else -> "Hello! How are you?"
            }
        }
        trimmed.contains("How are you", ignoreCase = true) || trimmed.contains("kaisa", ignoreCase = true) -> {
            when {
                isHindi -> "आप कैसे हैं? सब ठीक है?"
                isSpanish -> "¿Cómo estás? ¿Todo bien?"
                isFrench -> "Comment allez-vous?"
                isGerman -> "Wie geht es dir?"
                else -> "How are you? Everything good?"
            }
        }
        trimmed.contains("Where are you", ignoreCase = true) || trimmed.contains("kaha ho", ignoreCase = true) -> {
            when {
                isHindi -> "आप कहाँ हैं?"
                isSpanish -> "¿Dónde estás?"
                isFrench -> "Où êtes-vous?"
                else -> "Where are you currently?"
            }
        }
        trimmed.contains("Thank you", ignoreCase = true) || trimmed.contains("thanks", ignoreCase = true) || trimmed.contains("shukriya", ignoreCase = true) -> {
            when {
                isHindi -> "धन्यवाद / शुक्रिया!"
                isSpanish -> "¡Muchas gracias!"
                isFrench -> "Merci beaucoup!"
                isGerman -> "Vielen Dank!"
                else -> "Thank you very much!"
            }
        }
        else -> {
            // General localized prefix for arbitrary text
            when {
                isHindi -> "हिंदी अनुवाद: $trimmed"
                isSpanish -> "Traducción: $trimmed"
                isFrench -> "Traduction: $trimmed"
                isGerman -> "Übersetzung: $trimmed"
                isJapanese -> "翻訳: $trimmed"
                isArabic -> "ترجمة: $trimmed"
                isRussian -> "Перевод: $trimmed"
                else -> "Translated: $trimmed"
            }
        }
    }
}

@Composable
fun FullScreenImageViewerDialog(
    imageUri: String,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(imageUri)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Full Screen Photo Preview",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .align(Alignment.Center)
                )

                // Top Navigation & Action Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Black.copy(alpha = 0.8f), Color.Transparent)
                            )
                        )
                        .padding(horizontal = 16.dp, vertical = 16.dp)
                        .statusBarsPadding(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }

                    Text(
                        text = "Photo Preview",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )

                    IconButton(onClick = { /* Share placeholder */ }) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
