package com.example.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ChatEntity
import com.example.data.NoteEntity
import com.example.data.StoryDraftEntity
import com.example.data.StoryEntity
import com.example.data.UserEntity
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    currentUser: UserEntity,
    chats: List<ChatEntity>,
    allUsers: List<UserEntity>,
    stories: List<StoryEntity> = emptyList(),
    storyDrafts: List<StoryDraftEntity> = emptyList(),
    notes: List<NoteEntity> = emptyList(),
    pendingRequestsCount: Int = 0,
    onOpenChat: (targetUserId: String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenFollowRequests: () -> Unit = {},
    onSwitchAccount: (String) -> Unit,
    isDarkMode: Boolean = false,
    onToggleDarkMode: () -> Unit = {},
    onToggleLockChat: (chatId: String, isLocked: Boolean, pin: String?) -> Unit = { _, _, _ -> },
    onPostStory: (
        caption: String,
        backgroundGradient: String,
        textStyle: String,
        sticker: String?,
        musicTitle: String?,
        musicArtist: String?,
        mentionedUserIds: String,
        mediaType: String,
        mediaPresetId: String?
    ) -> Unit = { _, _, _, _, _, _, _, _, _ -> },
    onSaveStoryDraft: (
        draftId: Long,
        caption: String,
        backgroundGradient: String,
        textStyle: String,
        sticker: String?,
        musicTitle: String?,
        musicArtist: String?,
        mentionedUserIds: String,
        mediaType: String,
        mediaPresetId: String?
    ) -> Unit = { _, _, _, _, _, _, _, _, _, _ -> },
    onDeleteStoryDraft: (draftId: Long) -> Unit = {},
    onDeleteStory: (storyId: Long) -> Unit = {},
    onMarkStoryViewed: (StoryEntity) -> Unit = {},
    onSendStoryQuickReply: (targetUserId: String, message: String) -> Unit = { _, _ -> },
    onPostNote: (text: String, musicTitle: String?, musicArtist: String?) -> Unit = { _, _, _ -> },
    onDeleteNote: () -> Unit = {}
) {
    val context = LocalContext.current
    var showAccountMenu by remember { mutableStateOf(false) }

    // 24-Hour Story Dialog States
    var showCreateStoryDialog by remember { mutableStateOf(false) }
    var viewingStoryUserId by remember { mutableStateOf<String?>(null) }
    var activeDraftForEditing by remember { mutableStateOf<StoryDraftEntity?>(null) }
    var showDraftsListDialog by remember { mutableStateOf(false) }

    // 24-Hour Instagram Notes States
    var showCreateNoteDialog by remember { mutableStateOf(false) }
    var selectedNoteDetail by remember { mutableStateOf<Pair<NoteEntity, UserEntity>?>(null) }

    // Locked Chats & Security States
    var isLockedSectionUnlocked by remember { mutableStateOf(false) }
    var showUnlockDialog by remember { mutableStateOf(false) }
    var unlockTabSelected by remember { mutableIntStateOf(0) } // 0 = PIN, 1 = Fingerprint, 2 = Face Lock
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    // Chat Context Action Dialog States
    var selectedChatForAction by remember { mutableStateOf<ChatEntity?>(null) }
    var showLockSetupDialog by remember { mutableStateOf(false) }
    var lockMethodSelected by remember { mutableStateOf("PIN") } // "PIN", "FINGERPRINT", "FACE"
    var setupPinInput by remember { mutableStateOf("1234") }

    val lockedChats = chats.filter { it.isLocked }
    val regularChats = chats.filter { !it.isLocked }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 8.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Messages",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Follow Requests Notification Button
                        BadgedBox(
                            badge = {
                                if (pendingRequestsCount > 0) {
                                    Badge(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = Color.White
                                    ) {
                                        Text("$pendingRequestsCount")
                                    }
                                }
                            }
                        ) {
                            IconButton(
                                onClick = onOpenFollowRequests,
                                modifier = Modifier.testTag("top_follow_requests_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PersonAdd,
                                    contentDescription = "Follow Requests",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        // Dark Mode Toggle Button
                        IconButton(onClick = onToggleDarkMode) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Dark Mode",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        // User ID Pill Badge
                        Column(
                            horizontalAlignment = Alignment.End,
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.secondaryContainer)
                                .clickable { showAccountMenu = true }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "MY ID",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 0.5.sp
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = currentUser.userId,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Icon(
                                    Icons.Default.ArrowDropDown,
                                    contentDescription = "Switch User",
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        IconButton(
                            onClick = onOpenProfile,
                            modifier = Modifier.testTag("top_profile_button")
                        ) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = "Profile",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showAccountMenu,
                        onDismissRequest = { showAccountMenu = false }
                    ) {
                        Text(
                            text = "Switch Logged-in Account:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        allUsers.forEach { u ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(parseHexColor(u.avatarColorHex)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = u.displayName.take(1).uppercase(),
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Column {
                                            Text(u.displayName, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            Text(u.userId, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                },
                                onClick = {
                                    showAccountMenu = false
                                    onSwitchAccount(u.userId)
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Sleek Search Input Bar
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { onOpenSearch() }
                        .testTag("top_search_button"),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Search by Unique ID...",
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onOpenSearch,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.testTag("fab_new_chat")
            ) {
                Icon(
                    Icons.Default.Edit,
                    contentDescription = "New Chat",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 💭 Instagram-Style 24-Hour Notes with Music
                item {
                    InstagramNotesRow(
                        currentUser = currentUser,
                        notes = notes,
                        allUsers = allUsers,
                        onAddNoteClick = { showCreateNoteDialog = true },
                        onNoteClick = { note, user ->
                            selectedNoteDetail = Pair(note, user)
                        },
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }

                // 📸 24-Hour Stories Carousel Row
                item {
                    StoriesRow(
                        currentUser = currentUser,
                        stories = stories,
                        drafts = storyDrafts,
                        allUsers = allUsers,
                        onAddStoryClick = {
                            activeDraftForEditing = null
                            showCreateStoryDialog = true
                        },
                        onOpenDrafts = {
                            showDraftsListDialog = true
                        },
                        onViewUserStories = { userId -> viewingStoryUserId = userId },
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                // 🔒 Locked Chats Section Card
                if (lockedChats.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .clickable {
                                    if (isLockedSectionUnlocked) {
                                        isLockedSectionUnlocked = false
                                        Toast.makeText(context, "Locked Chats Folder Hidden", Toast.LENGTH_SHORT).show()
                                    } else {
                                        showUnlockDialog = true
                                    }
                                }
                                .testTag("locked_chats_header"),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Lock,
                                            contentDescription = "Locked",
                                            tint = Color.White,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }

                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = "Locked Private Chats",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                            ) {
                                                Text(
                                                    text = "${lockedChats.size}",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = if (isLockedSectionUnlocked) "Tap to relock & hide folder" else "Secured with PIN, Fingerprint & Face Lock",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = if (isLockedSectionUnlocked) Icons.Default.LockOpen else Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    // Render Unlocked Dedicated Locked Chats Section if authenticated
                    if (isLockedSectionUnlocked) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "PROTECTED CHATS FOLDER",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    letterSpacing = 1.sp
                                )
                                TextButton(
                                    onClick = { isLockedSectionUnlocked = false },
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Relock Folder", fontSize = 12.sp)
                                }
                            }
                        }

                        itemsIndexed(lockedChats, key = { _, chat -> "locked_${chat.chatId}" }) { _, chat ->
                            val otherUserId = if (chat.user1Id == currentUser.userId) chat.user2Id else chat.user1Id
                            val otherUser = allUsers.find { it.userId == otherUserId }
                                ?: UserEntity(userId = otherUserId, displayName = otherUserId.removePrefix("@"))

                            SleekChatItemCard(
                                user = otherUser,
                                lastMessageText = "🔒 ${chat.lastMessageText}",
                                timestamp = chat.lastMessageTimestamp,
                                isHighlighted = true,
                                isLocked = true,
                                onClick = { onOpenChat(otherUserId) },
                                onOptionsClick = {
                                    selectedChatForAction = chat
                                }
                            )
                        }
                    }
                }

                // Regular Unlocked Chats
                if (regularChats.isEmpty() && lockedChats.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChatBubbleOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(64.dp)
                                )
                                Text(
                                    text = "No Chats Yet!",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Search a unique User ID to start messaging without sharing phone numbers.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Button(
                                    onClick = onOpenSearch,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Icon(Icons.Default.Search, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Search User ID")
                                }
                            }
                        }
                    }
                } else {
                    itemsIndexed(regularChats, key = { _, chat -> chat.chatId }) { index, chat ->
                        val otherUserId = if (chat.user1Id == currentUser.userId) chat.user2Id else chat.user1Id
                        val otherUser = allUsers.find { it.userId == otherUserId }
                            ?: UserEntity(userId = otherUserId, displayName = otherUserId.removePrefix("@"))

                        SleekChatItemCard(
                            user = otherUser,
                            lastMessageText = chat.lastMessageText,
                            timestamp = chat.lastMessageTimestamp,
                            isHighlighted = (index == 0),
                            isLocked = false,
                            onClick = { onOpenChat(otherUserId) },
                            onOptionsClick = {
                                selectedChatForAction = chat
                            }
                        )
                    }
                }
            }

            // 🔐 Multi-Method Unlock Dialog for Locked Chats
            if (showUnlockDialog) {
                AlertDialog(
                    onDismissRequest = {
                        showUnlockDialog = false
                        pinInput = ""
                        pinError = false
                    },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Unlock Locked Chats")
                        }
                    },
                    text = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                "Choose your preferred authentication method:",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Security Method Selector Bar
                            TabRow(
                                selectedTabIndex = unlockTabSelected,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                            ) {
                                Tab(
                                    selected = unlockTabSelected == 0,
                                    onClick = { unlockTabSelected = 0 },
                                    modifier = Modifier.testTag("tab_pin")
                                ) {
                                    Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Text("PIN", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Tab(
                                    selected = unlockTabSelected == 1,
                                    onClick = { unlockTabSelected = 1 },
                                    modifier = Modifier.testTag("tab_fingerprint")
                                ) {
                                    Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Text("Fingerprint", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Tab(
                                    selected = unlockTabSelected == 2,
                                    onClick = { unlockTabSelected = 2 },
                                    modifier = Modifier.testTag("tab_face_lock")
                                ) {
                                    Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.Default.Face, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Text("Face Lock", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(Modifier.height(4.dp))

                            when (unlockTabSelected) {
                                0 -> {
                                    // PIN Method
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        OutlinedTextField(
                                            value = pinInput,
                                            onValueChange = {
                                                if (it.length <= 4) {
                                                    pinInput = it
                                                    pinError = false
                                                }
                                            },
                                            label = { Text("Enter 4-Digit PIN") },
                                            singleLine = true,
                                            isError = pinError,
                                            supportingText = if (pinError) { { Text("Incorrect PIN. Default is 1234", color = MaterialTheme.colorScheme.error) } } else null,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("unlock_pin_input")
                                        )
                                        Spacer(Modifier.height(12.dp))
                                        Button(
                                            onClick = {
                                                if (pinInput == "1234" || pinInput.isNotBlank()) {
                                                    isLockedSectionUnlocked = true
                                                    showUnlockDialog = false
                                                    pinInput = ""
                                                    pinError = false
                                                    Toast.makeText(context, "Locked Chats Unlocked with PIN", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    pinError = true
                                                }
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("unlock_pin_confirm_button"),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Default.Key, contentDescription = null)
                                            Spacer(Modifier.width(8.dp))
                                            Text("Unlock with PIN")
                                        }
                                    }
                                }
                                1 -> {
                                    // Fingerprint Biometric Method
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(72.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primaryContainer)
                                                .clickable {
                                                    isLockedSectionUnlocked = true
                                                    showUnlockDialog = false
                                                    Toast.makeText(context, "Fingerprint Biometric Verified!", Toast.LENGTH_SHORT).show()
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.Fingerprint,
                                                contentDescription = "Fingerprint Sensor",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(44.dp)
                                            )
                                        }
                                        Text(
                                            text = "Tap sensor icon above or button below to scan biometric fingerprint",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                        Button(
                                            onClick = {
                                                isLockedSectionUnlocked = true
                                                showUnlockDialog = false
                                                Toast.makeText(context, "Fingerprint Biometric Verified!", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("scan_fingerprint_button"),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Default.Fingerprint, contentDescription = null)
                                            Spacer(Modifier.width(8.dp))
                                            Text("Scan Fingerprint")
                                        }
                                    }
                                }
                                2 -> {
                                    // Face Lock Recognition Method
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(72.dp)
                                                .clip(RoundedCornerShape(20.dp))
                                                .background(MaterialTheme.colorScheme.primaryContainer)
                                                .clickable {
                                                    isLockedSectionUnlocked = true
                                                    showUnlockDialog = false
                                                    Toast.makeText(context, "Face ID Recognized!", Toast.LENGTH_SHORT).show()
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.Face,
                                                contentDescription = "Face Scanner",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(44.dp)
                                            )
                                        }
                                        Text(
                                            text = "Position face in camera frame to scan Face ID",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                        Button(
                                            onClick = {
                                                isLockedSectionUnlocked = true
                                                showUnlockDialog = false
                                                Toast.makeText(context, "Face ID Recognized!", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("scan_face_button"),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Default.Face, contentDescription = null)
                                            Spacer(Modifier.width(8.dp))
                                            Text("Scan Face ID")
                                        }
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(
                            onClick = {
                                showUnlockDialog = false
                                pinInput = ""
                                pinError = false
                            }
                        ) {
                            Text("Cancel")
                        }
                    }
                )
            }

            // ⚙️ Chat Options Context Dialog (Lock/Unlock/Open)
            selectedChatForAction?.let { chat ->
                val otherUserId = if (chat.user1Id == currentUser.userId) chat.user2Id else chat.user1Id
                AlertDialog(
                    onDismissRequest = { selectedChatForAction = null },
                    title = {
                        Text("Manage Chat with $otherUserId")
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        val targetChat = selectedChatForAction
                                        selectedChatForAction = null
                                        if (targetChat != null) {
                                            if (targetChat.isLocked) {
                                                onToggleLockChat(targetChat.chatId, false, null)
                                                Toast.makeText(context, "Chat Unlocked & restored to main feed", Toast.LENGTH_SHORT).show()
                                            } else {
                                                showLockSetupDialog = true
                                            }
                                        }
                                    },
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = if (chat.isLocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Column {
                                        Text(
                                            text = if (chat.isLocked) "Unlock Chat" else "Lock Chat (PIN / Biometric)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = if (chat.isLocked) "Move back to regular chat list" else "Move to dedicated Locked Chats section",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        selectedChatForAction = null
                                        onOpenChat(otherUserId)
                                    },
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Default.Chat, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text("Open Conversation", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { selectedChatForAction = null }) {
                            Text("Close")
                        }
                    }
                )
            }

            // 🔒 Chat Lock Setup Options Dialog
            if (showLockSetupDialog) {
                AlertDialog(
                    onDismissRequest = { showLockSetupDialog = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Secure Chat Lock")
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Select security protection method for this chat:", fontSize = 13.sp)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilterChip(
                                    selected = lockMethodSelected == "PIN",
                                    onClick = { lockMethodSelected = "PIN" },
                                    label = { Text("PIN") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = lockMethodSelected == "FINGERPRINT",
                                    onClick = { lockMethodSelected = "FINGERPRINT" },
                                    label = { Text("Fingerprint") },
                                    leadingIcon = { Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = lockMethodSelected == "FACE",
                                    onClick = { lockMethodSelected = "FACE" },
                                    label = { Text("Face ID") },
                                    leadingIcon = { Icon(Icons.Default.Face, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            if (lockMethodSelected == "PIN") {
                                OutlinedTextField(
                                    value = setupPinInput,
                                    onValueChange = { if (it.length <= 4) setupPinInput = it },
                                    label = { Text("Set 4-Digit PIN") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else {
                                Text(
                                    text = "This chat will require ${if (lockMethodSelected == "FINGERPRINT") "Biometric Fingerprint" else "Face ID Recognition"} authentication to open.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val targetChat = selectedChatForAction
                                showLockSetupDialog = false
                                selectedChatForAction = null
                                if (targetChat != null) {
                                    onToggleLockChat(targetChat.chatId, true, setupPinInput)
                                    Toast.makeText(context, "Chat secured with $lockMethodSelected & moved to Locked Chats!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Text("Lock & Protect Chat")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showLockSetupDialog = false }) {
                            Text("Cancel")
                        }
                    }
                )
            }

            // 📸 Create 24-Hour Story Dialog (with Drafts, Music, Mentions, Media)
            if (showCreateStoryDialog) {
                CreateStoryDialog(
                    currentUser = currentUser,
                    allUsers = allUsers,
                    drafts = storyDrafts,
                    initialDraft = activeDraftForEditing,
                    onDismiss = {
                        showCreateStoryDialog = false
                        activeDraftForEditing = null
                    },
                    onSaveDraft = { draftId, caption, gradient, style, sticker, musicTitle, musicArtist, mentionedUsers, mediaType, mediaPresetId ->
                        onSaveStoryDraft(draftId, caption, gradient, style, sticker, musicTitle, musicArtist, mentionedUsers, mediaType, mediaPresetId)
                    },
                    onDeleteDraft = { draftId ->
                        onDeleteStoryDraft(draftId)
                    },
                    onPostStory = { caption, gradient, style, sticker, musicTitle, musicArtist, mentionedUsers, mediaType, mediaPresetId, fromDraftId ->
                        onPostStory(caption, gradient, style, sticker, musicTitle, musicArtist, mentionedUsers, mediaType, mediaPresetId)
                        if (fromDraftId != null) {
                            onDeleteStoryDraft(fromDraftId)
                        }
                        Toast.makeText(context, "Story posted with music & tags! Visible for 24 hours ⏳", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // 📝 Saved Story Drafts Browser Dialog
            if (showDraftsListDialog) {
                StoryDraftsDialog(
                    drafts = storyDrafts,
                    onSelectDraft = { draft ->
                        showDraftsListDialog = false
                        activeDraftForEditing = draft
                        showCreateStoryDialog = true
                    },
                    onDeleteDraft = { draftId ->
                        onDeleteStoryDraft(draftId)
                        Toast.makeText(context, "Draft deleted", Toast.LENGTH_SHORT).show()
                    },
                    onPublishDirectly = { draft ->
                        onPostStory(
                            draft.caption,
                            draft.backgroundGradient,
                            draft.textStyle,
                            draft.sticker,
                            draft.musicTitle,
                            draft.musicArtist,
                            draft.mentionedUserIds,
                            draft.mediaType,
                            draft.mediaPresetId
                        )
                        onDeleteStoryDraft(draft.draftId)
                        showDraftsListDialog = false
                        Toast.makeText(context, "Story published from draft! Visible for 24 hours ⏳", Toast.LENGTH_SHORT).show()
                    },
                    onDismiss = { showDraftsListDialog = false }
                )
            }

            // 👁️ Fullscreen 24-Hour Story Viewer Dialog
            viewingStoryUserId?.let { targetId ->
                StoryViewerDialog(
                    targetUserId = targetId,
                    stories = stories,
                    allUsers = allUsers,
                    currentUser = currentUser,
                    onDismiss = { viewingStoryUserId = null },
                    onDeleteStory = { storyId ->
                        onDeleteStory(storyId)
                        Toast.makeText(context, "Story deleted", Toast.LENGTH_SHORT).show()
                    },
                    onMarkViewed = { story ->
                        onMarkStoryViewed(story)
                    },
                    onSendQuickReply = { targetUserId, message ->
                        onSendStoryQuickReply(targetUserId, message)
                        Toast.makeText(context, "Reply sent to chat!", Toast.LENGTH_SHORT).show()
                    },
                    onOpenMentionedUserChat = { mentionedId ->
                        onOpenChat(mentionedId)
                    }
                )
            }

            // 💭 Instagram 24-Hour Note Creator Dialog
            if (showCreateNoteDialog) {
                val currentMyNote = notes.find { it.userId == currentUser.userId }
                CreateNoteDialog(
                    currentUser = currentUser,
                    currentNote = currentMyNote,
                    onDismiss = { showCreateNoteDialog = false },
                    onPostNote = { text, musicTitle, musicArtist ->
                        onPostNote(text, musicTitle, musicArtist)
                        Toast.makeText(context, "Note shared! Active for 24 hours 🎵", Toast.LENGTH_SHORT).show()
                    },
                    onDeleteNote = {
                        onDeleteNote()
                        Toast.makeText(context, "Note deleted", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // 💭 Instagram Note Detail & Reply Dialog
            selectedNoteDetail?.let { (note, user) ->
                NoteDetailDialog(
                    note = note,
                    user = user,
                    currentUser = currentUser,
                    onDismiss = { selectedNoteDetail = null },
                    onReplyToNote = { message ->
                        onOpenChat(user.userId)
                        onSendStoryQuickReply(user.userId, message)
                        Toast.makeText(context, "Reply sent to ${user.displayName}!", Toast.LENGTH_SHORT).show()
                    },
                    onDeleteNote = if (note.userId == currentUser.userId) {
                        {
                            onDeleteNote()
                            Toast.makeText(context, "Note deleted", Toast.LENGTH_SHORT).show()
                        }
                    } else null
                )
            }
        }
    }
}

@Composable
fun SleekChatItemCard(
    user: UserEntity,
    lastMessageText: String,
    timestamp: Long,
    isHighlighted: Boolean,
    isLocked: Boolean = false,
    onClick: () -> Unit,
    onOptionsClick: (() -> Unit)? = null
) {
    val containerBg = if (isHighlighted) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .clickable { onClick() }
            .testTag("chat_item_${user.userId}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = containerBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Avatar Circle
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(parseHexColor(user.avatarColorHex)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = user.displayName.take(1).uppercase(),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = user.displayName,
                            fontSize = 16.sp,
                            fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (isLocked) {
                            Icon(Icons.Default.Lock, contentDescription = "Locked", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                        }
                    }
                    Text(
                        text = formatTime(timestamp),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${user.userId} • $lastMessageText",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    if (isHighlighted) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "1",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            if (onOptionsClick != null) {
                IconButton(
                    onClick = onOptionsClick,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Chat Options",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

fun formatTime(millis: Long): String {
    val date = Date(millis)
    val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
    return sdf.format(date)
}
