package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SleekPrimary = Color(0xFF6750A4)
val SleekOnPrimary = Color(0xFFFFFFFF)
val SleekPrimaryContainer = Color(0xFFEADDFF)
val SleekOnPrimaryContainer = Color(0xFF21005D)

val SleekSecondary = Color(0xFF7D5260)
val SleekSecondaryContainer = Color(0xFFE8DEF8)
val SleekOnSecondaryContainer = Color(0xFF1D192B)

val SleekBackground = Color(0xFFFEF7FF)
val SleekOnBackground = Color(0xFF1D1B20)

val SleekSurface = Color(0xFFF7F2FA)
val SleekOnSurface = Color(0xFF1D1B20)

val SleekSurfaceVariant = Color(0xFFECE6F0)
val SleekOnSurfaceVariant = Color(0xFF49454F)

val SleekSentBubble = Color(0xFFEADDFF)
val SleekReceivedBubble = Color(0xFFF3EDF7)

