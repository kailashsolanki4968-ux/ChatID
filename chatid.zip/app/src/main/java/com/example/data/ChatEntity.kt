package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey
    val chatId: String, // e.g. "@kailash_@priya_s"
    val user1Id: String,
    val user2Id: String,
    val lastMessageText: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val unreadCountUser1: Int = 0,
    val unreadCountUser2: Int = 0,
    val isLocked: Boolean = false,
    val lockPin: String? = null,
    val wallpaper: String = "DEFAULT"
)

