package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "story_drafts")
data class StoryDraftEntity(
    @PrimaryKey(autoGenerate = true)
    val draftId: Long = 0,
    val userId: String,
    val caption: String,
    val mediaUrl: String? = null,
    val mediaType: String = "GRADIENT", // "GRADIENT", "PHOTO", "VIDEO"
    val mediaPresetId: String? = null,
    val backgroundGradient: String = "SUNSET",
    val textStyle: String = "BOLD",
    val sticker: String? = null,
    val musicTitle: String? = null,
    val musicArtist: String? = null,
    val mentionedUserIds: String = "",
    val lastModified: Long = System.currentTimeMillis()
)
