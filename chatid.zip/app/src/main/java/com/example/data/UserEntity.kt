package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val userId: String, // e.g. "@kailash", "@priya_s", "@alex_dev"
    val displayName: String,
    val passwordHash: String = "123456",
    val bio: String = "Hey there! I am using ChatID.",
    val avatarColorHex: String = "#00A884",
    val isOnline: Boolean = true,
    val lastSeen: Long = System.currentTimeMillis(),
    val isPublicProfile: Boolean = true,
    val isBlocked: Boolean = false
)

