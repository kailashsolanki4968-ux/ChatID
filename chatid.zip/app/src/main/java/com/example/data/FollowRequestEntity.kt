package com.example.data

import androidx.room.Entity

@Entity(
    tableName = "follow_requests",
    primaryKeys = ["senderId", "receiverId"]
)
data class FollowRequestEntity(
    val senderId: String,
    val receiverId: String,
    val status: String, // "PENDING", "ACCEPTED", "REJECTED"
    val timestamp: Long = System.currentTimeMillis()
)

data class FollowRequestWithUser(
    val request: FollowRequestEntity,
    val user: UserEntity
)
