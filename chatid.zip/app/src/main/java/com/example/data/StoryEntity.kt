package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey(autoGenerate = true)
    val storyId: Long = 0,
    val userId: String,
    val caption: String,
    val mediaUrl: String? = null,
    val mediaType: String = "GRADIENT", // "GRADIENT", "PHOTO", "VIDEO"
    val mediaPresetId: String? = null, // e.g. "CITY_LIGHTS", "SUNSET_BEACH", "NEON_CYBER", "CAFE_VIBES", "MOUNTAIN_VIEW", "RAINY_WINDOW", "STUDY_DESK"
    val backgroundGradient: String = "SUNSET", // "SUNSET", "OCEAN", "EMERALD", "PURPLE_DREAM", "NEON_NIGHT", "CRIMSON", "MINIMAL_DARK"
    val textStyle: String = "BOLD", // "BOLD", "CLASSIC", "NEON", "TYPEWRITER"
    val sticker: String? = null, // e.g. "🔥", "✨", "☕", "🎉", "🚀", "💡"
    val musicTitle: String? = null, // e.g. "Kesariya"
    val musicArtist: String? = null, // e.g. "Arijit Singh"
    val mentionedUserIds: String = "", // Comma-separated list e.g. "@priya_s,@alex_dev"
    val timestamp: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + (24 * 60 * 60 * 1000L), // 24 Hours duration
    val viewedByUserIds: String = "" // Comma-separated list of user IDs who have viewed
)
