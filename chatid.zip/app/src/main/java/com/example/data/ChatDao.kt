package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {

    // --- User Queries ---
    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    fun observeUserById(userId: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE userId LIKE '%' || :query || '%' OR displayName LIKE '%' || :query || '%'")
    fun searchUsers(query: String): Flow<List<UserEntity>>

    @Query("SELECT * FROM users ORDER BY displayName ASC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<UserEntity>)

    @Update
    suspend fun updateUser(user: UserEntity)

    // --- Chat Queries ---
    @Query("SELECT * FROM chats WHERE user1Id = :userId OR user2Id = :userId ORDER BY lastMessageTimestamp DESC")
    fun getChatsForUser(userId: String): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats WHERE chatId = :chatId LIMIT 1")
    suspend fun getChatById(chatId: String): ChatEntity?

    @Query("SELECT * FROM chats WHERE chatId = :chatId LIMIT 1")
    fun observeChatById(chatId: String): Flow<ChatEntity?>

    @Query("UPDATE chats SET wallpaper = :wallpaper WHERE chatId = :chatId")
    suspend fun updateChatWallpaper(chatId: String, wallpaper: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChat(chat: ChatEntity)

    @Update
    suspend fun updateChat(chat: ChatEntity)

    // --- Message Queries ---
    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
    fun getMessagesForChat(chatId: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("UPDATE messages SET reaction = :reaction WHERE messageId = :messageId")
    suspend fun updateMessageReaction(messageId: Long, reaction: String?)

    @Query("UPDATE messages SET content = :newContent, isEdited = 1, editedTimestamp = :timestamp WHERE messageId = :messageId")
    suspend fun updateMessageContent(messageId: Long, newContent: String, timestamp: Long)

    @Query("UPDATE messages SET isDeleted = 1 WHERE messageId = :messageId")
    suspend fun deleteMessage(messageId: Long)

    @Query("UPDATE chats SET isLocked = :isLocked, lockPin = :pin WHERE chatId = :chatId")
    suspend fun updateChatLockState(chatId: String, isLocked: Boolean, pin: String?)

    @Query("UPDATE users SET isBlocked = :isBlocked WHERE userId = :userId")
    suspend fun updateUserBlockState(userId: String, isBlocked: Boolean)

    @Query("UPDATE users SET isPublicProfile = :isPublic WHERE userId = :userId")
    suspend fun updateUserPrivacyState(userId: String, isPublic: Boolean)

    @Query("DELETE FROM chats WHERE chatId = :chatId")
    suspend fun deleteChat(chatId: String)

    @Query("UPDATE messages SET status = 'READ' WHERE chatId = :chatId AND receiverId = :userId")
    suspend fun markMessagesAsRead(chatId: String, userId: String)

    @Query("UPDATE chats SET unreadCountUser1 = 0 WHERE chatId = :chatId AND user1Id = :userId")
    suspend fun clearUnreadUser1(chatId: String, userId: String)

    @Query("UPDATE chats SET unreadCountUser2 = 0 WHERE chatId = :chatId AND user2Id = :userId")
    suspend fun clearUnreadUser2(chatId: String, userId: String)

    // --- Follow Requests Queries ---
    @Query("SELECT * FROM follow_requests WHERE (senderId = :user1Id AND receiverId = :user2Id) OR (senderId = :user2Id AND receiverId = :user1Id) LIMIT 1")
    fun observeFollowRequest(user1Id: String, user2Id: String): Flow<FollowRequestEntity?>

    @Query("SELECT * FROM follow_requests WHERE (senderId = :user1Id AND receiverId = :user2Id) OR (senderId = :user2Id AND receiverId = :user1Id) LIMIT 1")
    suspend fun getFollowRequest(user1Id: String, user2Id: String): FollowRequestEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFollowRequest(request: FollowRequestEntity)

    @Query("UPDATE follow_requests SET status = :status WHERE (senderId = :user1Id AND receiverId = :user2Id) OR (senderId = :user2Id AND receiverId = :user1Id)")
    suspend fun updateFollowRequestStatus(user1Id: String, user2Id: String, status: String)

    @Query("DELETE FROM follow_requests WHERE (senderId = :user1Id AND receiverId = :user2Id) OR (senderId = :user2Id AND receiverId = :user1Id)")
    suspend fun deleteFollowRequest(user1Id: String, user2Id: String)

    @Query("SELECT * FROM follow_requests WHERE receiverId = :userId AND status = 'PENDING' ORDER BY timestamp DESC")
    fun observeIncomingFollowRequests(userId: String): Flow<List<FollowRequestEntity>>

    @Query("SELECT * FROM follow_requests WHERE senderId = :userId AND status = 'PENDING' ORDER BY timestamp DESC")
    fun observeOutgoingFollowRequests(userId: String): Flow<List<FollowRequestEntity>>

    // --- 24-Hour Story Queries ---
    @Query("SELECT * FROM stories WHERE expiresAt > :currentTime ORDER BY timestamp ASC")
    fun getActiveStories(currentTime: Long): Flow<List<StoryEntity>>

    @Query("SELECT * FROM stories WHERE userId = :userId AND expiresAt > :currentTime ORDER BY timestamp ASC")
    fun getActiveStoriesForUser(userId: String, currentTime: Long): Flow<List<StoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryEntity): Long

    @Query("DELETE FROM stories WHERE storyId = :storyId")
    suspend fun deleteStory(storyId: Long)

    @Query("UPDATE stories SET viewedByUserIds = :viewers WHERE storyId = :storyId")
    suspend fun updateStoryViewers(storyId: Long, viewers: String)

    @Query("DELETE FROM stories WHERE expiresAt <= :currentTime")
    suspend fun cleanupExpiredStories(currentTime: Long)

    // --- 24-Hour Notes Queries (Instagram-style) ---
    @Query("SELECT * FROM user_notes WHERE expiresAt > :currentTime ORDER BY timestamp DESC")
    fun getActiveNotes(currentTime: Long): Flow<List<NoteEntity>>

    @Query("SELECT * FROM user_notes WHERE userId = :userId AND expiresAt > :currentTime LIMIT 1")
    fun observeUserNote(userId: String, currentTime: Long): Flow<NoteEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)

    @Query("DELETE FROM user_notes WHERE userId = :userId")
    suspend fun deleteNote(userId: String)

    @Query("DELETE FROM user_notes WHERE expiresAt <= :currentTime")
    suspend fun cleanupExpiredNotes(currentTime: Long)

    // --- Story Drafts Queries ---
    @Query("SELECT * FROM story_drafts WHERE userId = :userId ORDER BY lastModified DESC")
    fun getStoryDraftsForUser(userId: String): Flow<List<StoryDraftEntity>>

    @Query("SELECT * FROM story_drafts WHERE draftId = :draftId LIMIT 1")
    suspend fun getStoryDraftById(draftId: Long): StoryDraftEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStoryDraft(draft: StoryDraftEntity): Long

    @Query("DELETE FROM story_drafts WHERE draftId = :draftId")
    suspend fun deleteStoryDraft(draftId: Long)
}
