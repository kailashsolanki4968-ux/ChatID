package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val messageId: Long = 0,
    val chatId: String,
    val senderId: String,
    val receiverId: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val messageType: String = "TEXT", // "TEXT", "IMAGE", "VIDEO", "FILE", "VOICE", "CALL_LOG"
    val status: String = "READ", // "SENT", "DELIVERED", "READ"
    val reaction: String? = null, // e.g. "❤️", "👍", "😂"
    val isEdited: Boolean = false,
    val isDeleted: Boolean = false,
    val editedTimestamp: Long? = null,
    val fileUri: String? = null,
    val fileName: String? = null
)

