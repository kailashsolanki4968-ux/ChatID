package com.example.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlin.random.Random

class ChatRepository(private val dao: ChatDao) {

    private val repositoryScope = CoroutineScope(Dispatchers.IO)

    suspend fun seedInitialDataIfEmpty() {
        val existingUsers = dao.getAllUsers().firstOrNull()
        if (existingUsers.isNullOrEmpty()) {
            val defaultUsers = listOf(
                UserEntity(
                    userId = "@kailash",
                    displayName = "Kailash Solanki",
                    bio = "Hey there! I'm using ChatID (No Phone Number required)",
                    avatarColorHex = "#00A884",
                    isOnline = true
                ),
                UserEntity(
                    userId = "@priya_s",
                    displayName = "Priya Sharma",
                    bio = "Design Lead | Ping me anytime!",
                    avatarColorHex = "#E91E63",
                    isOnline = true
                ),
                UserEntity(
                    userId = "@alex_dev",
                    displayName = "Alex Rivers",
                    bio = "Android Kotlin Developer 🚀",
                    avatarColorHex = "#2196F3",
                    isOnline = true
                ),
                UserEntity(
                    userId = "@sarah_m",
                    displayName = "Sarah Miller",
                    bio = "Coffee lover ☕ & Photographer 📸",
                    avatarColorHex = "#9C27B0",
                    isOnline = false
                ),
                UserEntity(
                    userId = "@rahul_v",
                    displayName = "Rahul Verma",
                    bio = "Tech Enthusiast | Always online",
                    avatarColorHex = "#FF9800",
                    isOnline = true
                )
            )
            dao.insertUsers(defaultUsers)

            // Seed initial chat between @kailash and @priya_s
            val chatId1 = getCanonicalChatId("@kailash", "@priya_s")
            val chat1 = ChatEntity(
                chatId = chatId1,
                user1Id = "@kailash",
                user2Id = "@priya_s",
                lastMessageText = "Hey Kailash! Welcome to ChatID. No phone number needed!",
                lastMessageTimestamp = System.currentTimeMillis() - 1000 * 60 * 5
            )
            dao.insertChat(chat1)

            val m1 = MessageEntity(
                chatId = chatId1,
                senderId = "@priya_s",
                receiverId = "@kailash",
                content = "Hey Kailash! Welcome to ChatID 🎉",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 10,
                status = "READ"
            )
            val m2 = MessageEntity(
                chatId = chatId1,
                senderId = "@kailash",
                receiverId = "@priya_s",
                content = "Thanks Priya! Love that we don't need phone numbers, just our User ID!",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 7,
                status = "READ"
            )
            val m3 = MessageEntity(
                chatId = chatId1,
                senderId = "@priya_s",
                receiverId = "@kailash",
                content = "Exactly! Just search anyone using their unique ID like @priya_s or @alex_dev.",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                status = "READ"
            )
            dao.insertMessage(m1)
            dao.insertMessage(m2)
            dao.insertMessage(m3)

            // Seed initial chat between @kailash and @alex_dev
            val chatId2 = getCanonicalChatId("@kailash", "@alex_dev")
            val chat2 = ChatEntity(
                chatId = chatId2,
                user1Id = "@kailash",
                user2Id = "@alex_dev",
                lastMessageText = "Awesome Jetpack Compose UI!",
                lastMessageTimestamp = System.currentTimeMillis() - 1000 * 60 * 30
            )
            dao.insertChat(chat2)

            val m4 = MessageEntity(
                chatId = chatId2,
                senderId = "@alex_dev",
                receiverId = "@kailash",
                content = "Hey Kailash, check out this ID-based chat app!",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 30,
                status = "READ"
            )
            dao.insertMessage(m4)

            // Seed accepted follow requests for initial contacts
            dao.insertFollowRequest(FollowRequestEntity("@kailash", "@priya_s", "ACCEPTED"))
            dao.insertFollowRequest(FollowRequestEntity("@kailash", "@alex_dev", "ACCEPTED"))

            // Seed pending incoming follow requests to @kailash
            dao.insertFollowRequest(FollowRequestEntity("@sarah_m", "@kailash", "PENDING", System.currentTimeMillis() - 1000 * 60 * 120))
            dao.insertFollowRequest(FollowRequestEntity("@rahul_v", "@kailash", "PENDING", System.currentTimeMillis() - 1000 * 60 * 45))

            // Seed initial active 24-hour stories with music, mentions, and media presets
            val now = System.currentTimeMillis()
            dao.insertStory(
                StoryEntity(
                    userId = "@priya_s",
                    caption = "Designing sleek new UI with music! Tagging @kailash 🎨✨",
                    backgroundGradient = "SUNSET",
                    mediaType = "PHOTO",
                    mediaPresetId = "CAFE_VIBES",
                    textStyle = "BOLD",
                    sticker = "🚀",
                    musicTitle = "Kesariya",
                    musicArtist = "Arijit Singh",
                    mentionedUserIds = "@kailash",
                    timestamp = now - (1000 * 60 * 60 * 2),
                    expiresAt = now + (22 * 60 * 60 * 1000L)
                )
            )
            dao.insertStory(
                StoryEntity(
                    userId = "@alex_dev",
                    caption = "Late night coding session with synth beats ⚡ Mentioning @priya_s @kailash",
                    backgroundGradient = "NEON_NIGHT",
                    mediaType = "VIDEO",
                    mediaPresetId = "NEON_CYBER",
                    textStyle = "NEON",
                    sticker = "💻",
                    musicTitle = "Blinding Lights",
                    musicArtist = "The Weeknd",
                    mentionedUserIds = "@priya_s,@kailash",
                    timestamp = now - (1000 * 60 * 60 * 4),
                    expiresAt = now + (20 * 60 * 60 * 1000L)
                )
            )
            dao.insertStory(
                StoryEntity(
                    userId = "@sarah_m",
                    caption = "Mountain morning coffee breeze ☕🏔️",
                    backgroundGradient = "EMERALD",
                    mediaType = "PHOTO",
                    mediaPresetId = "MOUNTAIN_VIEW",
                    textStyle = "CLASSIC",
                    sticker = "☕",
                    musicTitle = "Night Changes",
                    musicArtist = "One Direction",
                    mentionedUserIds = "",
                    timestamp = now - (1000 * 60 * 60 * 1),
                    expiresAt = now + (23 * 60 * 60 * 1000L)
                )
            )

            // Seed initial 24-Hour Notes with Music (Instagram Style)
            dao.insertNote(
                NoteEntity(
                    userId = "@priya_s",
                    text = "Working on ChatID icons 🎨",
                    musicTitle = "Levitating",
                    musicArtist = "Dua Lipa",
                    timestamp = now - (1000 * 60 * 60 * 1),
                    expiresAt = now + (23 * 60 * 60 * 1000L)
                )
            )
            dao.insertNote(
                NoteEntity(
                    userId = "@alex_dev",
                    text = "Compiling build ☕⚡",
                    musicTitle = "Starboy",
                    musicArtist = "The Weeknd",
                    timestamp = now - (1000 * 60 * 60 * 3),
                    expiresAt = now + (21 * 60 * 60 * 1000L)
                )
            )
            dao.insertNote(
                NoteEntity(
                    userId = "@sarah_m",
                    text = "Chilling in the cafe 🌿",
                    musicTitle = "Apna Bana Le",
                    musicArtist = "Arijit Singh",
                    timestamp = now - (1000 * 60 * 30),
                    expiresAt = now + (23 * 60 * 60 * 1000L + 1000 * 60 * 30)
                )
            )

            // Seed initial Story Draft
            dao.insertStoryDraft(
                StoryDraftEntity(
                    userId = "@john_doe",
                    caption = "Weekend trip plans & roadtrip vibes! 🏔️✨",
                    backgroundGradient = "EMERALD",
                    textStyle = "NEON",
                    sticker = "🚀",
                    musicTitle = "Night Changes",
                    musicArtist = "One Direction",
                    mentionedUserIds = "@priya_s",
                    mediaType = "PHOTO",
                    mediaPresetId = "MOUNTAIN_VIEW",
                    lastModified = now - (1000 * 60 * 45)
                )
            )
        }
    }

    suspend fun getUser(userId: String): UserEntity? {
        val formatted = formatUserId(userId)
        return dao.getUserById(formatted)
    }

    fun observeUser(userId: String): Flow<UserEntity?> {
        val formatted = formatUserId(userId)
        return dao.observeUserById(formatted)
    }

    fun searchUsers(query: String): Flow<List<UserEntity>> {
        val cleanQuery = query.trim().removePrefix("@")
        return dao.searchUsers(cleanQuery)
    }

    fun getAllUsers(): Flow<List<UserEntity>> {
        return dao.getAllUsers()
    }

    suspend fun registerOrLoginUser(rawUserId: String, displayName: String, bio: String): UserEntity {
        val formattedId = formatUserId(rawUserId)
        val existing = dao.getUserById(formattedId)
        if (existing != null) {
            return existing
        }
        val avatarColors = listOf("#00A884", "#E91E63", "#2196F3", "#9C27B0", "#FF9800", "#00BCD4", "#4CAF50")
        val color = avatarColors[Random.nextInt(avatarColors.size)]
        val newUser = UserEntity(
            userId = formattedId,
            displayName = if (displayName.isNotBlank()) displayName else formattedId.removePrefix("@"),
            bio = if (bio.isNotBlank()) bio else "Hey there! I am using ChatID.",
            avatarColorHex = color,
            isOnline = true
        )
        dao.insertUser(newUser)
        return newUser
    }

    fun getChatsForUser(userId: String): Flow<List<ChatEntity>> {
        return dao.getChatsForUser(formatUserId(userId))
    }

    fun getMessagesForChat(chatId: String): Flow<List<MessageEntity>> {
        return dao.getMessagesForChat(chatId)
    }

    suspend fun getOrCreateChat(user1Id: String, user2Id: String): ChatEntity {
        val u1 = formatUserId(user1Id)
        val u2 = formatUserId(user2Id)
        val chatId = getCanonicalChatId(u1, u2)
        val existing = dao.getChatById(chatId)
        if (existing != null) return existing

        val newChat = ChatEntity(
            chatId = chatId,
            user1Id = u1,
            user2Id = u2,
            lastMessageText = "Chat started",
            lastMessageTimestamp = System.currentTimeMillis()
        )
        dao.insertChat(newChat)
        return newChat
    }

    suspend fun sendMessage(
        senderId: String,
        receiverId: String,
        content: String,
        type: String = "TEXT",
        fileUri: String? = null
    ) {
        val sId = formatUserId(senderId)
        val rId = formatUserId(receiverId)
        val chatId = getCanonicalChatId(sId, rId)

        // Ensure chat entity exists
        getOrCreateChat(sId, rId)

        val message = MessageEntity(
            chatId = chatId,
            senderId = sId,
            receiverId = rId,
            content = content,
            timestamp = System.currentTimeMillis(),
            messageType = type,
            fileUri = fileUri,
            status = "SENT"
        )
        dao.insertMessage(message)

        // Update chat last message
        val currentChat = dao.getChatById(chatId)
        if (currentChat != null) {
            val updated = currentChat.copy(
                lastMessageText = when (type) {
                    "IMAGE" -> "📷 Photo"
                    "VIDEO" -> "🎥 Video"
                    "FILE" -> "📁 Document"
                    "VOICE" -> "🎤 Voice message"
                    else -> content
                },
                lastMessageTimestamp = System.currentTimeMillis()
            )
            dao.updateChat(updated)
        }

        // Trigger simulated auto-reply if sending to a mock recipient contact
        triggerSimulatedAutoReplyIfNeeded(sId, rId, content)
    }

    suspend fun editMessage(messageId: Long, newContent: String) {
        dao.updateMessageContent(messageId, newContent, System.currentTimeMillis())
    }

    suspend fun deleteMessage(messageId: Long) {
        dao.deleteMessage(messageId)
    }

    suspend fun setChatLockState(chatId: String, isLocked: Boolean, pin: String?) {
        dao.updateChatLockState(chatId, isLocked, pin)
    }

    suspend fun setUserBlockState(userId: String, isBlocked: Boolean) {
        dao.updateUserBlockState(formatUserId(userId), isBlocked)
    }

    suspend fun setUserPrivacyState(userId: String, isPublic: Boolean) {
        dao.updateUserPrivacyState(formatUserId(userId), isPublic)
    }

    suspend fun deleteChat(chatId: String) {
        dao.deleteChat(chatId)
    }

    private fun triggerSimulatedAutoReplyIfNeeded(senderId: String, receiverId: String, userText: String) {
        // If receiver is a bot/demo contact and not equal to sender
        if (receiverId != senderId && (receiverId.startsWith("@") && receiverId != "@custom")) {
            repositoryScope.launch {
                delay(1200) // Realistic typing delay

                val chatId = getCanonicalChatId(senderId, receiverId)
                val replyText = generateSimulatedReply(receiverId, userText)

                val replyMessage = MessageEntity(
                    chatId = chatId,
                    senderId = receiverId,
                    receiverId = senderId,
                    content = replyText,
                    timestamp = System.currentTimeMillis(),
                    messageType = "TEXT",
                    status = "READ"
                )
                dao.insertMessage(replyMessage)

                val currentChat = dao.getChatById(chatId)
                if (currentChat != null) {
                    val updated = currentChat.copy(
                        lastMessageText = replyText,
                        lastMessageTimestamp = System.currentTimeMillis()
                    )
                    dao.updateChat(updated)
                }
            }
        }
    }

    private fun generateSimulatedReply(recipientId: String, text: String): String {
        val lower = text.lowercase()
        return when {
            lower.contains("hi") || lower.contains("hello") || lower.contains("hey") || lower.contains("namaste") ->
                "Hey! Thanks for messaging me on ChatID. No phone numbers, total privacy! 😊"
            lower.contains("kaise ho") || lower.contains("how are you") ->
                "I'm doing great! Loved how easy it is to find friends using their unique ID like $recipientId!"
            lower.contains("id") || lower.contains("search") ->
                "Yes! You can search anyone using their User ID in the top search bar."
            lower.contains("whatsapp") ->
                "ChatID works just like WhatsApp, but without requiring any phone number registration!"
            else ->
                "Got your message: \"$text\". ChatID makes messaging seamless with unique IDs! 👍"
        }
    }

    suspend fun addReaction(messageId: Long, reaction: String?) {
        dao.updateMessageReaction(messageId, reaction)
    }

    fun observeChatById(chatId: String): Flow<ChatEntity?> {
        return dao.observeChatById(chatId)
    }

    suspend fun updateChatWallpaper(chatId: String, wallpaper: String) {
        dao.updateChatWallpaper(chatId, wallpaper)
    }

    suspend fun markAsRead(chatId: String, currentUserId: String) {
        dao.markMessagesAsRead(chatId, formatUserId(currentUserId))
        val formatted = formatUserId(currentUserId)
        dao.clearUnreadUser1(chatId, formatted)
        dao.clearUnreadUser2(chatId, formatted)
    }

    suspend fun updateUserProfile(userId: String, newName: String, newBio: String) {
        val user = dao.getUserById(formatUserId(userId))
        if (user != null) {
            val updated = user.copy(displayName = newName, bio = newBio)
            dao.updateUser(updated)
        }
    }

    // --- Follow Requests ---
    fun observeFollowRequest(user1Id: String, user2Id: String): Flow<FollowRequestEntity?> {
        val u1 = formatUserId(user1Id)
        val u2 = formatUserId(user2Id)
        return dao.observeFollowRequest(u1, u2)
    }

    suspend fun getFollowRequest(user1Id: String, user2Id: String): FollowRequestEntity? {
        val u1 = formatUserId(user1Id)
        val u2 = formatUserId(user2Id)
        return dao.getFollowRequest(u1, u2)
    }

    suspend fun sendFollowRequest(senderId: String, receiverId: String) {
        val sId = formatUserId(senderId)
        val rId = formatUserId(receiverId)
        val request = FollowRequestEntity(
            senderId = sId,
            receiverId = rId,
            status = "PENDING",
            timestamp = System.currentTimeMillis()
        )
        dao.insertFollowRequest(request)

        // Automatically trigger simulated auto-accept if recipient is demo contact
        if (rId != sId && rId.startsWith("@")) {
            repositoryScope.launch {
                delay(1500) // Simulated delay
                val current = dao.getFollowRequest(sId, rId)
                if (current != null && current.status == "PENDING") {
                    dao.updateFollowRequestStatus(sId, rId, "ACCEPTED")
                }
            }
        }
    }

    suspend fun acceptFollowRequest(user1Id: String, user2Id: String) {
        val u1 = formatUserId(user1Id)
        val u2 = formatUserId(user2Id)
        dao.updateFollowRequestStatus(u1, u2, "ACCEPTED")
    }

    suspend fun declineFollowRequest(user1Id: String, user2Id: String) {
        val u1 = formatUserId(user1Id)
        val u2 = formatUserId(user2Id)
        dao.deleteFollowRequest(u1, u2)
    }

    fun observeIncomingFollowRequests(userId: String): Flow<List<FollowRequestWithUser>> {
        val uId = formatUserId(userId)
        return dao.observeIncomingFollowRequests(uId).combine(dao.getAllUsers()) { requests, users ->
            val userMap = users.associateBy { it.userId }
            requests.map { req ->
                val sender = userMap[req.senderId] ?: UserEntity(req.senderId, req.senderId.removePrefix("@"))
                FollowRequestWithUser(req, sender)
            }
        }
    }

    fun observeOutgoingFollowRequests(userId: String): Flow<List<FollowRequestWithUser>> {
        val uId = formatUserId(userId)
        return dao.observeOutgoingFollowRequests(uId).combine(dao.getAllUsers()) { requests, users ->
            val userMap = users.associateBy { it.userId }
            requests.map { req ->
                val receiver = userMap[req.receiverId] ?: UserEntity(req.receiverId, req.receiverId.removePrefix("@"))
                FollowRequestWithUser(req, receiver)
            }
        }
    }

    // --- 24-Hour Story Methods ---
    fun observeActiveStories(): Flow<List<StoryEntity>> {
        return dao.getActiveStories(System.currentTimeMillis())
    }

    suspend fun postStory(
        userId: String,
        caption: String,
        backgroundGradient: String = "SUNSET",
        textStyle: String = "BOLD",
        sticker: String? = null,
        musicTitle: String? = null,
        musicArtist: String? = null,
        mentionedUserIds: String = "",
        mediaType: String = "GRADIENT",
        mediaPresetId: String? = null
    ): Long {
        val uId = formatUserId(userId)
        val now = System.currentTimeMillis()
        val story = StoryEntity(
            userId = uId,
            caption = caption,
            backgroundGradient = backgroundGradient,
            textStyle = textStyle,
            sticker = sticker,
            musicTitle = musicTitle,
            musicArtist = musicArtist,
            mentionedUserIds = mentionedUserIds,
            mediaType = mediaType,
            mediaPresetId = mediaPresetId,
            timestamp = now,
            expiresAt = now + (24 * 60 * 60 * 1000L), // exactly 24 hours expiry
            viewedByUserIds = uId
        )
        return dao.insertStory(story)
    }

    suspend fun deleteStory(storyId: Long) {
        dao.deleteStory(storyId)
    }

    suspend fun markStoryAsViewed(story: StoryEntity, viewerUserId: String) {
        val vId = formatUserId(viewerUserId)
        val currentViewers = story.viewedByUserIds.split(",").filter { it.isNotBlank() }.toMutableSet()
        if (!currentViewers.contains(vId)) {
            currentViewers.add(vId)
            dao.updateStoryViewers(story.storyId, currentViewers.joinToString(","))
        }
    }

    suspend fun cleanupExpiredStories() {
        dao.cleanupExpiredStories(System.currentTimeMillis())
    }

    // --- 24-Hour Instagram Notes Methods ---
    fun observeActiveNotes(): Flow<List<NoteEntity>> {
        return dao.getActiveNotes(System.currentTimeMillis())
    }

    fun observeUserNote(userId: String): Flow<NoteEntity?> {
        return dao.observeUserNote(formatUserId(userId), System.currentTimeMillis())
    }

    suspend fun postNote(userId: String, text: String, musicTitle: String? = null, musicArtist: String? = null) {
        val uId = formatUserId(userId)
        val now = System.currentTimeMillis()
        val note = NoteEntity(
            userId = uId,
            text = text,
            musicTitle = musicTitle,
            musicArtist = musicArtist,
            timestamp = now,
            expiresAt = now + (24 * 60 * 60 * 1000L)
        )
        dao.insertNote(note)
    }

    suspend fun deleteNote(userId: String) {
        dao.deleteNote(formatUserId(userId))
    }

    suspend fun cleanupExpiredNotes() {
        dao.cleanupExpiredNotes(System.currentTimeMillis())
    }

    // --- Story Drafts Methods ---
    fun getStoryDraftsForUser(userId: String): Flow<List<StoryDraftEntity>> {
        return dao.getStoryDraftsForUser(formatUserId(userId))
    }

    suspend fun saveStoryDraft(
        draftId: Long = 0,
        userId: String,
        caption: String,
        backgroundGradient: String = "SUNSET",
        textStyle: String = "BOLD",
        sticker: String? = null,
        musicTitle: String? = null,
        musicArtist: String? = null,
        mentionedUserIds: String = "",
        mediaType: String = "GRADIENT",
        mediaPresetId: String? = null
    ): Long {
        val uId = formatUserId(userId)
        val draft = StoryDraftEntity(
            draftId = draftId,
            userId = uId,
            caption = caption,
            backgroundGradient = backgroundGradient,
            textStyle = textStyle,
            sticker = sticker,
            musicTitle = musicTitle,
            musicArtist = musicArtist,
            mentionedUserIds = mentionedUserIds,
            mediaType = mediaType,
            mediaPresetId = mediaPresetId,
            lastModified = System.currentTimeMillis()
        )
        return dao.insertStoryDraft(draft)
    }

    suspend fun deleteStoryDraft(draftId: Long) {
        dao.deleteStoryDraft(draftId)
    }

    suspend fun getStoryDraftById(draftId: Long): StoryDraftEntity? {
        return dao.getStoryDraftById(draftId)
    }

    companion object {
        fun formatUserId(id: String): String {
            val trimmed = id.trim()
            return if (trimmed.startsWith("@")) trimmed.lowercase() else "@${trimmed.lowercase()}"
        }

        fun getCanonicalChatId(user1: String, user2: String): String {
            val u1 = formatUserId(user1)
            val u2 = formatUserId(user2)
            return if (u1 < u2) "${u1}_${u2}" else "${u2}_${u1}"
        }
    }
}
