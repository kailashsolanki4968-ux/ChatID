package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_notes")
data class NoteEntity(
    @PrimaryKey
    val userId: String,
    val text: String,
    val musicTitle: String? = null,
    val musicArtist: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + (24 * 60 * 60 * 1000L) // 24 Hours duration
)
