package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.*
import com.example.ui.theme.ChatIDTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: ChatViewModel = viewModel()
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

            ChatIDTheme(darkTheme = isDarkMode) {
                ChatIDApp(viewModel = viewModel, isDarkMode = isDarkMode)
            }
        }
    }
}

@Composable
fun ChatIDApp(viewModel: ChatViewModel = viewModel(), isDarkMode: Boolean = false) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val activeChatId by viewModel.activeChatId.collectAsStateWithLifecycle()
    val activeRecipient by viewModel.activeRecipient.collectAsStateWithLifecycle()
    val activeChatMessages by viewModel.activeChatMessages.collectAsStateWithLifecycle()
    val chatsList by viewModel.chatsList.collectAsStateWithLifecycle()
    val allUsersList by viewModel.allUsersList.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()
    val activeFollowRequest by viewModel.activeFollowRequest.collectAsStateWithLifecycle()
    val activeChatEntity by viewModel.activeChatEntity.collectAsStateWithLifecycle()
    val incomingFollowRequests by viewModel.incomingFollowRequests.collectAsStateWithLifecycle()
    val outgoingFollowRequests by viewModel.outgoingFollowRequests.collectAsStateWithLifecycle()
    val activeStories by viewModel.activeStories.collectAsStateWithLifecycle()
    val storyDrafts by viewModel.storyDrafts.collectAsStateWithLifecycle()
    val activeNotes by viewModel.activeNotes.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf("CHATS") } // "CHATS", "SEARCH", "PROFILE", "FOLLOW_REQUESTS"

    val user = currentUser
    if (user == null) {
        AuthScreen(
            onLoginSuccess = { userId, name, bio ->
                viewModel.loginOrRegister(userId, name, bio)
            },
            allUsers = allUsersList,
            onQuickSwitch = { userId ->
                viewModel.switchAccount(userId)
            }
        )
    } else {
        if (activeChatId != null) {
            BackHandler {
                viewModel.closeActiveChat()
            }
        } else if (currentScreen != "CHATS") {
            BackHandler {
                currentScreen = "CHATS"
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            if (activeChatId != null && activeRecipient != null) {
                val currentChat = chatsList.find { it.chatId == activeChatId }
                ChatDetailScreen(
                    currentUser = user,
                    recipient = activeRecipient!!,
                    messages = activeChatMessages,
                    followRequest = activeFollowRequest,
                    onSendFollowRequest = { viewModel.sendFollowRequest(activeRecipient!!.userId) },
                    onAcceptFollowRequest = { viewModel.acceptFollowRequest(activeRecipient!!.userId) },
                    onDeclineFollowRequest = { viewModel.declineFollowRequest(activeRecipient!!.userId) },
                    onBack = { viewModel.closeActiveChat() },
                    onSendMessage = { content, type, fileUri -> viewModel.sendMessage(content, type, fileUri) },
                    onEditMessage = { msg, newContent, onResult -> viewModel.editMessage(msg, newContent, onResult) },
                    onDeleteMessage = { msgId -> viewModel.deleteMessage(msgId) },
                    onAddReaction = { msgId, reaction -> viewModel.addReaction(msgId, reaction) },
                    onStartCall = { isVideo -> viewModel.startCall(activeRecipient!!, isVideo) },
                    onToggleLockChat = { isLocked, pin -> viewModel.setChatLock(activeChatId!!, isLocked, pin) },
                    onBlockUser = { isBlocked -> viewModel.blockUser(activeRecipient!!.userId, isBlocked) },
                    isChatLocked = currentChat?.isLocked ?: false,
                    chatWallpaper = activeChatEntity?.wallpaper ?: "DEFAULT",
                    onUpdateWallpaper = { newWallpaperKey -> viewModel.updateChatWallpaper(newWallpaperKey) }
                )
            } else {
                when (currentScreen) {
                    "SEARCH" -> {
                        SearchIdScreen(
                            searchQuery = searchQuery,
                            onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                            searchResults = searchResults,
                            currentUser = user,
                            onOpenChat = { targetId ->
                                viewModel.openChatWith(targetId)
                            },
                            onBack = { currentScreen = "CHATS" }
                        )
                    }
                    "PROFILE" -> {
                        ProfileScreen(
                            currentUser = user,
                            pendingRequestsCount = incomingFollowRequests.size,
                            onUpdateProfile = { name, bio ->
                                viewModel.updateProfile(name, bio)
                            },
                            onTogglePrivacy = { isPublic ->
                                viewModel.togglePublicProfile(isPublic)
                            },
                            onOpenFollowRequests = { currentScreen = "FOLLOW_REQUESTS" },
                            onSwitchUserClick = {
                                viewModel.currentUser.value = null
                                currentScreen = "CHATS"
                            },
                            onBack = { currentScreen = "CHATS" },
                            isDarkMode = isDarkMode,
                            onToggleDarkMode = { viewModel.toggleDarkMode() }
                        )
                    }
                    "FOLLOW_REQUESTS" -> {
                        FollowRequestsScreen(
                            currentUser = user,
                            incomingRequests = incomingFollowRequests,
                            outgoingRequests = outgoingFollowRequests,
                            onAcceptRequest = { targetId -> viewModel.acceptFollowRequest(targetId) },
                            onDeclineRequest = { targetId -> viewModel.declineFollowRequest(targetId) },
                            onSendRequest = { targetId -> viewModel.sendFollowRequest(targetId) },
                            onOpenChat = { targetId ->
                                viewModel.openChatWith(targetId)
                                currentScreen = "CHATS"
                            },
                            onBack = { currentScreen = "CHATS" }
                        )
                    }
                    else -> { // "CHATS"
                        ChatListScreen(
                            currentUser = user,
                            chats = chatsList,
                            allUsers = allUsersList,
                            stories = activeStories,
                            storyDrafts = storyDrafts,
                            notes = activeNotes,
                            pendingRequestsCount = incomingFollowRequests.size,
                            onOpenChat = { targetUserId ->
                                viewModel.openChatWith(targetUserId)
                            },
                            onOpenSearch = { currentScreen = "SEARCH" },
                            onOpenProfile = { currentScreen = "PROFILE" },
                            onOpenFollowRequests = { currentScreen = "FOLLOW_REQUESTS" },
                            onSwitchAccount = { userId ->
                                viewModel.switchAccount(userId)
                            },
                            isDarkMode = isDarkMode,
                            onToggleDarkMode = { viewModel.toggleDarkMode() },
                            onToggleLockChat = { chatId, isLocked, pin ->
                                viewModel.setChatLock(chatId, isLocked, pin)
                            },
                            onPostStory = { caption, gradient, style, sticker, musicTitle, musicArtist, mentionedUsers, mediaType, mediaPresetId ->
                                viewModel.postStory(
                                    caption = caption,
                                    backgroundGradient = gradient,
                                    textStyle = style,
                                    sticker = sticker,
                                    musicTitle = musicTitle,
                                    musicArtist = musicArtist,
                                    mentionedUserIds = mentionedUsers,
                                    mediaType = mediaType,
                                    mediaPresetId = mediaPresetId
                                )
                            },
                            onSaveStoryDraft = { draftId, caption, gradient, style, sticker, musicTitle, musicArtist, mentionedUsers, mediaType, mediaPresetId ->
                                viewModel.saveStoryDraft(
                                    draftId = draftId,
                                    caption = caption,
                                    backgroundGradient = gradient,
                                    textStyle = style,
                                    sticker = sticker,
                                    musicTitle = musicTitle,
                                    musicArtist = musicArtist,
                                    mentionedUserIds = mentionedUsers,
                                    mediaType = mediaType,
                                    mediaPresetId = mediaPresetId
                                )
                            },
                            onDeleteStoryDraft = { draftId ->
                                viewModel.deleteStoryDraft(draftId)
                            },
                            onDeleteStory = { storyId ->
                                viewModel.deleteStory(storyId)
                            },
                            onMarkStoryViewed = { story ->
                                viewModel.markStoryAsViewed(story)
                            },
                            onSendStoryQuickReply = { targetUserId, message ->
                                viewModel.openChatWith(targetUserId)
                                viewModel.sendMessage(message)
                            },
                            onPostNote = { text, musicTitle, musicArtist ->
                                viewModel.postNote(text, musicTitle, musicArtist)
                            },
                            onDeleteNote = {
                                viewModel.deleteNote()
                            }
                        )
                    }
                }
            }

            // Call Overlay Dialog if active call
            activeCall?.let { call ->
                CallDialog(
                    callState = call,
                    onEndCall = { viewModel.endCall() }
                )
            }
        }
    }
}

